metadata description = 'Cloud-Operator Container App: grant AcrPull to the cloud-operator managed identity on an existing Azure Container Registry'
metadata version = '1.0.0-0'

targetScope = 'resourceGroup'

@description('Full resource ID of the Azure Container Registry that holds the cloud-operator image.')
param acrResourceId string

@description('Principal ID of the managed identity that needs AcrPull on the registry.')
param principalId string

var acrResourceIdParts = split(acrResourceId, '/')

resource acr 'Microsoft.ContainerRegistry/registries@2023-01-01-preview' existing = {
  name: acrResourceIdParts[8]
}

resource acrPullRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acrResourceId, principalId, 'AcrPull')
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '7f951dda-4ed3-4680-a7ca-43fe172d538d')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}
