metadata description = 'Cloud-Operator Target Subscription Resources (one-tenant multi-subscription)'
metadata version = '1.0.0-0'

targetScope = 'subscription'

// ============================================================
// Parameters
// ============================================================

@description('Principal ID of the cloud-operator managed identity to assign roles to.')
param cloudOperatorPrincipalId string

@description('Azure region where the target resource group is created.')
param targetRegion string

@description('Name of the resource group in the target subscription that holds the Event Grid system topic. Created if it does not exist.')
param targetResourceGroupName string = 'qualys-target-scanning-rg'

@description('Resource ID of the Service Bus queue in the service subscription that receives Function App events.')
param functionEventQueueResourceId string

@description('Resource ID of an existing subscription-level Event Grid system topic to reuse instead of creating a new one. Azure allows only one system topic per subscription source, so set this if the target subscription already has one (e.g. auto-created in a Default-EventGrid resource group).')
param existingEventGridSystemTopicResourceId string = ''

@description('Azure Subscription ID of the service subscription where the scanning infrastructure (Service Bus, Cosmos DB, cloud-operator) is deployed.')
param serviceSubscriptionId string

@description('Azure region where the service subscription stack is deployed (e.g., eastus, westus2).')
param serviceSubscriptionRegion string

@secure()
@description('Send-only connection string for the service subscription onboarding queue.')
param onboardingQueueConnectionString string

// ============================================================
// Role Assignments for cloud-operator managed identity
// ============================================================

module targetRoleAssignments 'qualys-cs-service-account-scanning-sub-roles.bicep' = {
  name: 'qualys-sub-roles-${substring(subscription().subscriptionId, 0, 8)}-${uniqueString(subscription().subscriptionId, cloudOperatorPrincipalId, targetRegion)}'
  scope: subscription()
  params: {
    principalId: cloudOperatorPrincipalId
    subscriptionId: subscription().subscriptionId
  }
}

// ============================================================
// Resource Group
// ============================================================

resource targetResourceGroup 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: targetResourceGroupName
  location: targetRegion
}

// ============================================================
// Event Grid Resources
// ============================================================

module eventGridResources 'qualys-cs-target-subscription-event-grid-rg.bicep' = {
  name: 'qualys-eventgrid-resources-${uniqueString(cloudOperatorPrincipalId, targetRegion)}'
  scope: resourceGroup(targetResourceGroupName)
  params: {
    targetSubscriptionId: subscription().subscriptionId
    functionEventQueueResourceId: functionEventQueueResourceId
    existingEventGridSystemTopicResourceId: existingEventGridSystemTopicResourceId
  }
  dependsOn: [
    targetResourceGroup
  ]
}

// ============================================================
// Onboarding Notifier
// ============================================================

module onboardingNotifier 'qualys-cs-target-subscription-onboarding-notifier.bicep' = {
  name: 'qualys-onboarding-notifier-${uniqueString(cloudOperatorPrincipalId, targetRegion)}'
  scope: resourceGroup(targetResourceGroupName)
  params: {
    serviceSubscriptionId: serviceSubscriptionId
    serviceSubscriptionRegion: serviceSubscriptionRegion
    onboardingQueueConnectionString: onboardingQueueConnectionString
    location: targetRegion
  }
  dependsOn: [
    targetResourceGroup
    targetRoleAssignments
  ]
}

// ============================================================
// Outputs
// ============================================================

output eventGridTopicPrincipalId string = eventGridResources.outputs.eventGridTopicPrincipalId
