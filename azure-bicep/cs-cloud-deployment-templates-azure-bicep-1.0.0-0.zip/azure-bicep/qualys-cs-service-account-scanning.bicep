metadata description = 'Cloud-Operator Azure Container App Scanning Infrastructure - Service Subscription Resources'
metadata version = '1.0.0-0'
metadata equivalent = 'qualys-cs-service-account-scanning.yaml (AWS CloudFormation)'

targetScope = 'resourceGroup'

// ============================================================
// Parameters
// ============================================================

@description('Azure Subscription ID where this template is deployed (service subscription). Leave empty to use current subscription.')
param serviceSubscriptionId string = ''

@description('Container image URI for the cloud-operator orchestrator (e.g., qualys.azurecr.io/cloud-operator:latest). Managed-identity-based pulls (configured via acrResourceId) only work against Azure Container Registry. For other registries (Docker Hub, GHCR, etc.), the image must either be public or containerRegistryUsername/containerRegistryPassword must be supplied.')
param cloudOperatorImageUri string


@description('Qualys access token for qscanner (QUALYS_ACCESS_TOKEN env var)')
@secure()
param qualysAccessToken string = ''

@description('Optional OAuth client ID for qscanner (QUALYS_CLIENT_ID env var)')
param qualysClientId string = ''

@description('Optional OAuth client secret for qscanner (QUALYS_CLIENT_SECRET env var)')
@secure()
param qualysClientSecret string = ''

@description('Comma-separated scan types passed to qscanner (leave empty for qscanner default)')
param scanTypes string = 'pkg,fileinsight,aiinsight'

@description('Optional HTTP/HTTPS proxy URL (e.g., http://proxy.example.com:3128)')
param proxy string = ''

@description('Optional base64-encoded CA certificate')
@secure()
param caCertificate string = ''

@description('Log level for the cloud-operator container (debug, info, warn, error, fatal)')
@allowed(['debug', 'info', 'warn', 'error', 'fatal'])
param logLevel string = 'info'

@description('Qualys gateway URL passed to qscanner via --gateway-url (e.g., https://gateway.qg1.apps.qualys.com)')
param gatewayUrl string

@description('CPU cores allocated to the cloud-operator container (e.g., 0.5, 1.0, 2.0)')
param cloudOperatorCpu string = '1.0'

@description('Memory allocated to the cloud-operator container (e.g., 1.0Gi, 2.0Gi, 4.0Gi)')
param cloudOperatorMemory string = '2.0Gi'

@description('Scan Azure Container Apps in the service subscription itself. Set to \'false\' to only scan target subscriptions.')
@allowed(['true', 'false'])
param scanServiceSubscription string = 'true'

@description('Interval in minutes between reconciliation passes that detect and clean up onboarded subscriptions whose target resource group no longer exists. Set to \'0\' to disable.')
param reconciliationIntervalMin string = '1440'

@description('Number of concurrent workers used by the cloud-operator to process Azure Function scan jobs (AZURE_FUNCTION_SCAN_WORKER_COUNT env var)')
param azureFunctionScanWorkerCount string = '1'

@description('Azure Service Bus SKU. Standard or Premium required for topics/subscriptions.')
@allowed(['Basic', 'Standard', 'Premium'])
param serviceBusSkuName string = 'Standard'

@description('Primary Azure region for all resources. Defaults to the resource group location.')
param location string = resourceGroup().location


@description('Resource ID of the Azure Container Registry that holds the cloud-operator image. Required for granting AcrPull to the managed identity so the Container App can pull the image during deployment. Leave empty if cloudOperatorImageUri points to a non-ACR registry (use containerRegistryUsername/containerRegistryPassword for private non-ACR registries, or leave all three empty for a public image).')
param acrResourceId string = ''

@description('Registry server for a private non-ACR registry (e.g., index.docker.io, ghcr.io). Only used when acrResourceId is empty and containerRegistryUsername/containerRegistryPassword are supplied. If left empty, the server is derived from cloudOperatorImageUri.')
param containerRegistryServer string = ''

@description('Username for a private non-ACR registry. Ignored when acrResourceId is supplied (ACR uses managed identity instead).')
param containerRegistryUsername string = ''

@description('Password or access token for a private non-ACR registry. Ignored when acrResourceId is supplied (ACR uses managed identity instead).')
@secure()
param containerRegistryPassword string = ''

@description('Optional resource ID of an existing Event Grid system topic for the service subscription. When supplied, the template creates the Event Grid subscription on this topic instead of creating a new one.')
param existingEventGridSystemTopicResourceId string = ''

// ============================================================
// Variables
// ============================================================

var resolvedSubscriptionId = empty(serviceSubscriptionId) ? subscription().subscriptionId : serviceSubscriptionId
var scanServiceSubscriptionBool = scanServiceSubscription == 'true'
var useExistingEventGridSystemTopic = !empty(existingEventGridSystemTopicResourceId)
var existingEventGridSystemTopicResourceIdParts = split(existingEventGridSystemTopicResourceId, '/')

var useAcrManagedIdentity = !empty(acrResourceId)
var useContainerRegistryCredentials = !useAcrManagedIdentity && !empty(containerRegistryUsername) && !empty(containerRegistryPassword)
var resolvedContainerRegistryServer = !empty(containerRegistryServer) ? containerRegistryServer : split(cloudOperatorImageUri, '/')[0]

var serviceBusNamespaceName = 'qualys-cloud-scanning-bus-${uniqueString(resourceGroup().id)}'
var functionEventQueueName = 'qualys-azure-function-events'
var onboardingQueueName = 'qualys-onboarding-events'

var cosmosAccountName = 'qualys-cloud-scanning-db-${uniqueString(resourceGroup().id)}'
var scanJobsDatabaseName = 'qualys-scanning'
var scanJobsContainerName = 'qualys-azure-function-scan-jobs'
var onboardedAccountsContainerName = 'qualys-onboarded-subscriptions'

var containerAppEnvName = 'qualys-cloud-operator-env'
var containerAppName = 'qualys-cloud-operator'
var managedIdentityName = 'qualys-cloud-operator-identity'
var logAnalyticsWorkspaceName = 'qualys-cloud-operator-logs'

var eventGridTopicName = 'qualys-azure-container-app-events-topic'
var eventGridSubscriptionName = 'qualys-azure-container-app-events-sub'

// ============================================================
// Cosmos DB
// ============================================================

resource cosmosAccount 'Microsoft.DocumentDB/databaseAccounts@2023-04-15' = {
  name: cosmosAccountName
  location: location
  kind: 'GlobalDocumentDB'
  properties: {
    databaseAccountOfferType: 'Standard'
    consistencyPolicy: {
      defaultConsistencyLevel: 'Session'
    }
    enableAutomaticFailover: false
    enableMultipleWriteLocations: false
    backupPolicy: {
      type: 'Continuous'
    }
    locations: [
      {
        locationName: location
        failoverPriority: 0
        isZoneRedundant: false
      }
    ]
    capabilities: [
      {
        name: 'EnableServerless'
      }
    ]
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudScanning'
  }
}

resource scanJobsDatabase 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2023-04-15' = {
  parent: cosmosAccount
  name: scanJobsDatabaseName
  properties: {
    resource: {
      id: scanJobsDatabaseName
    }
  }
}

resource scanJobsContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2023-04-15' = {
  parent: scanJobsDatabase
  name: scanJobsContainerName
  properties: {
    resource: {
      id: scanJobsContainerName
      partitionKey: {
        paths: ['/function_resource_id']
        kind: 'Hash'
      }
      indexingPolicy: {
        indexingMode: 'consistent'
        includedPaths: [
          { path: '/subscription_id/?' }
          { path: '/region/?' }
          { path: '/status/?' }
        ]
        excludedPaths: [{ path: '/*' }]
      }
      defaultTtl: 2592000
    }
  }
}

resource onboardedAccountsContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2023-04-15' = {
  parent: scanJobsDatabase
  name: onboardedAccountsContainerName
  properties: {
    resource: {
      id: onboardedAccountsContainerName
      partitionKey: {
        paths: ['/subscription_id']
        kind: 'Hash'
      }
      indexingPolicy: {
        indexingMode: 'consistent'
        includedPaths: [
          { path: '/subscription_id/?' }
          { path: '/account_type/?' }
          { path: '/status/?' }
          { path: '/onboarded_at/?' }
          { path: '/updated_at/?' }
          { path: '/resource_group/?' }
        ]
        excludedPaths: [{ path: '/*' }]
      }
    }
  }
}

// ============================================================
// Service Bus
// ============================================================

resource serviceBusNamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: serviceBusNamespaceName
  location: location
  sku: {
    name: serviceBusSkuName
    tier: serviceBusSkuName
  }
  properties: {
    minimumTlsVersion: '1.2'
    disableLocalAuth: false
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudScanning'
  }
}

resource functionEventQueue 'Microsoft.ServiceBus/namespaces/queues@2022-10-01-preview' = {
  parent: serviceBusNamespace
  name: functionEventQueueName
  properties: {
    lockDuration: 'PT5M'
    maxSizeInMegabytes: 5120
    requiresDuplicateDetection: false
    requiresSession: false
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
    maxDeliveryCount: 10
    enablePartitioning: false
  }
}

resource onboardingQueue 'Microsoft.ServiceBus/namespaces/queues@2022-10-01-preview' = {
  parent: serviceBusNamespace
  name: onboardingQueueName
  properties: {
    lockDuration: 'PT5M'
    maxSizeInMegabytes: 5120
    requiresDuplicateDetection: false
    requiresSession: false
    defaultMessageTimeToLive: 'P14D'
    deadLetteringOnMessageExpiration: true
    enableBatchedOperations: true
    maxDeliveryCount: 5
    enablePartitioning: false
  }
}

resource targetOnboardingSenderAuthRule 'Microsoft.ServiceBus/namespaces/queues/authorizationRules@2022-10-01-preview' = {
  parent: onboardingQueue
  name: 'qualys-target-onboarding-sender'
  properties: {
    rights: [
      'Send'
    ]
  }
}

// ============================================================
// Managed Identity
// ============================================================

resource managedIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: managedIdentityName
  location: location
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudOperatorOrchestrator'
  }
}

// ============================================================
// Role Assignments
// ============================================================

resource serviceBusDataOwnerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(resourceGroup().id, managedIdentityName, 'ServiceBusDataOwner')
  scope: serviceBusNamespace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '090c5cfd-751d-490a-894a-3ce6f1109419')
    principalId: managedIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource cosmosDataContributorRole 'Microsoft.DocumentDB/databaseAccounts/sqlRoleAssignments@2023-04-15' = {
  parent: cosmosAccount
  name: guid(resourceGroup().id, managedIdentityName, 'CosmosDataContributor')
  properties: {
    principalId: managedIdentity.properties.principalId
    roleDefinitionId: '${cosmosAccount.id}/sqlRoleDefinitions/00000000-0000-0000-0000-000000000002'
    scope: cosmosAccount.id
  }
}

// Padded with placeholder segments when acrResourceId is empty (acrPullRole module is skipped
// in that case via its own condition) so split() always yields enough parts to index into,
// avoiding an "array index out of bounds" template validation error on the default empty value.
var acrResourceIdParts = split(!empty(acrResourceId) ? acrResourceId : '/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/placeholder', '/')

module acrPullRole 'qualys-cs-acr-pull-role.bicep' = if (!empty(acrResourceId)) {
  name: 'qualys-acr-pull-role-${uniqueString(acrResourceId, managedIdentityName)}'
  scope: resourceGroup(acrResourceIdParts[2], acrResourceIdParts[4])
  params: {
    acrResourceId: acrResourceId
    principalId: managedIdentity.properties.principalId
  }
}

module subscriptionRoleAssignments 'qualys-cs-service-account-scanning-sub-roles.bicep' = {
  name: 'qualys-subscription-role-assignments-${uniqueString(managedIdentityName, location)}'
  scope: subscription()
  params: {
    principalId: managedIdentity.properties.principalId
    subscriptionId: subscription().subscriptionId
  }
}

// ============================================================
// Log Analytics Workspace
// ============================================================

resource logAnalyticsWorkspace 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: logAnalyticsWorkspaceName
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudScanning'
  }
}

// ============================================================
// Container App Managed Environment (conditional)
// ============================================================

resource containerAppEnv 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: containerAppEnvName
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalyticsWorkspace.properties.customerId
        sharedKey: logAnalyticsWorkspace.listKeys().primarySharedKey
      }
    }
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudScanning'
  }
}

// ============================================================
// Container App
// ============================================================

resource containerApp 'Microsoft.App/containerApps@2023-05-01' = {
  name: containerAppName
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${managedIdentity.id}': {}
    }
  }
  properties: {
    managedEnvironmentId: containerAppEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      secrets: concat(
        !empty(qualysAccessToken) ? [
          {
            name: 'qualys-access-token'
            value: qualysAccessToken
          }
        ] : [],
        !empty(qualysClientSecret) ? [
          {
            name: 'qualys-client-secret'
            value: qualysClientSecret
          }
        ] : [],
        !empty(caCertificate) ? [
          {
            name: 'ca-certificate'
            value: caCertificate
          }
        ] : [],
        useContainerRegistryCredentials ? [
          {
            name: 'container-registry-password'
            value: containerRegistryPassword
          }
        ] : []
      )
      ingress: {
        external: false
        targetPort: 8080
        allowInsecure: false
      }
      registries: concat(useAcrManagedIdentity ? [
        {
          identity: managedIdentity.id
          server: resolvedContainerRegistryServer
        }
      ] : [], useContainerRegistryCredentials ? [
        {
          server: resolvedContainerRegistryServer
          username: containerRegistryUsername
          passwordSecretRef: 'container-registry-password'
        }
      ] : [])
    }
    template: {
      containers: [
        {
          name: 'cloud-operator'
          image: cloudOperatorImageUri
          resources: {
            cpu: json(cloudOperatorCpu)
            memory: cloudOperatorMemory
          }
          env: [
            {
              name: 'CLOUD_PROVIDER'
              value: 'azure'
            }
            {
              name: 'AZURE_FUNCTION_SCAN_JOBS_TABLE'
              value: scanJobsContainerName
            }
            {
              name: 'ONBOARDED_ACCOUNTS_TABLE'
              value: onboardedAccountsContainerName
            }
            {
              name: 'COSMOS_DB_ACCOUNT_ENDPOINT'
              value: cosmosAccount.properties.documentEndpoint
            }
            {
              name: 'COSMOS_DB_DATABASE_NAME'
              value: scanJobsDatabaseName
            }
            {
              name: 'SERVICEBUS_NAMESPACE'
              value: '${serviceBusNamespaceName}.servicebus.windows.net'
            }
            {
              name: 'AZURE_FUNCTION_EVENTS_QUEUE'
              value: functionEventQueueName
            }
            {
              name: 'AZURE_FUNCTION_SCAN_WORKER_COUNT'
              value: azureFunctionScanWorkerCount
            }
            {
              name: 'ONBOARDING_EVENTS_QUEUE'
              value: onboardingQueueName
            }
            {
              name: 'AZURE_CLIENT_ID'
              value: managedIdentity.properties.clientId
            }
            {
              name: 'SERVICE_SUBSCRIPTION_ID'
              value: resolvedSubscriptionId
            }
            {
              name: 'SERVICE_RESOURCE_GROUP_NAME'
              value: resourceGroup().name
            }
            {
              name: 'SCAN_SERVICE_SUBSCRIPTION'
              value: scanServiceSubscription
            }
            {
              name: 'GATEWAY_URL'
              value: gatewayUrl
            }
            {
              name: 'QUALYS_ACCESS_TOKEN'
              secretRef: !empty(qualysAccessToken) ? 'qualys-access-token' : null
              value: !empty(qualysAccessToken) ? null : ''
            }
            {
              name: 'QUALYS_CLIENT_ID'
              value: qualysClientId
            }
            {
              name: 'QUALYS_CLIENT_SECRET'
              secretRef: !empty(qualysClientSecret) ? 'qualys-client-secret' : null
              value: !empty(qualysClientSecret) ? null : ''
            }
            {
              name: 'SCAN_TYPES'
              value: scanTypes
            }
            {
              name: 'PROXY'
              value: proxy
            }
            {
              name: 'CA_CERTIFICATE'
              secretRef: !empty(caCertificate) ? 'ca-certificate' : null
              value: !empty(caCertificate) ? null : ''
            }
            {
              name: 'LOG_LEVEL'
              value: logLevel
            }
            {
              name: 'AZURE_TENANT_ID'
              value: tenant().tenantId
            }
            {
              name: 'ENABLE_AZURE_FUNCTION_SCANNING'
              value: 'true'
            }
            {
              name: 'RECONCILIATION_INTERVAL_MIN'
              value: reconciliationIntervalMin
            }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 5
      }
    }
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysCloudOperatorOrchestrator'
  }
  dependsOn: [
    functionEventQueue
    onboardingQueue
    scanJobsContainer
    onboardedAccountsContainer
    serviceBusDataOwnerRole
    cosmosDataContributorRole
    acrPullRole
  ]
}

// ============================================================
// Event Grid (conditional on scanServiceSubscription)
// ============================================================

resource eventGridTopic 'Microsoft.EventGrid/systemTopics@2022-06-15' = if (scanServiceSubscriptionBool && !useExistingEventGridSystemTopic) {
  name: eventGridTopicName
  location: 'global'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    source: '/subscriptions/${resolvedSubscriptionId}'
    topicType: 'Microsoft.Resources.Subscriptions'
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysAzureFunctionEvents'
  }
}

resource eventGridServiceBusSenderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (scanServiceSubscriptionBool && !useExistingEventGridSystemTopic) {
  name: guid(resourceGroup().id, eventGridTopicName, 'ServiceBusDataSender')
  scope: serviceBusNamespace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39')
    principalId: eventGridTopic!.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// Grants the cloud-operator managed identity permission to read role assignments on the
// Service Bus namespace, solely so eventGridRbacPropagationCheck below can poll for the
// eventGridServiceBusSenderRole assignment to become visible. By this point in the
// deployment, managedIdentity's other role assignments have already had the rest of the
// deployment to propagate, so this grant is not itself subject to the same race.
resource eventGridRoleAssignmentReaderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (scanServiceSubscriptionBool && !useExistingEventGridSystemTopic) {
  name: guid(resourceGroup().id, managedIdentityName, 'RoleAssignmentReader')
  scope: serviceBusNamespace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'acdd72a7-3385-48ef-bd42-f606fba81ae7') // Reader
    principalId: managedIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// Azure RBAC role assignments succeed as soon as the write completes, but the permission
// can take a couple of minutes to replicate through Azure AD/RBAC. Event Grid validates
// delivery permissions to the destination immediately on creation, so without confirming
// propagation first, the subscription intermittently fails with "Managed Identity
// Authorization Error" (see aka.ms/egmsivalidation). This polls for the role assignment
// to actually become visible instead of guessing with a fixed sleep.
resource eventGridRbacPropagationCheck 'Microsoft.Resources/deploymentScripts@2020-10-01' = if (scanServiceSubscriptionBool && !useExistingEventGridSystemTopic) {
  name: 'qualys-eventgrid-rbac-check-${uniqueString(resourceGroup().id, eventGridTopicName)}'
  location: location
  kind: 'AzureCLI'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${managedIdentity.id}': {}
    }
  }
  properties: {
    azCliVersion: '2.50.0'
    retentionInterval: 'PT1H'
    cleanupPreference: 'OnSuccess'
    timeout: 'PT10M'
    environmentVariables: [
      {
        name: 'PRINCIPAL_ID'
        value: eventGridTopic!.identity.principalId
      }
      {
        name: 'SERVICEBUS_SCOPE'
        value: serviceBusNamespace.id
      }
      {
        name: 'ROLE_DEFINITION_ID'
        value: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39')
      }
    ]
    scriptContent: '''#!/bin/bash
set -e
MAX_RETRIES=30
RETRY=0
while [ $RETRY -lt $MAX_RETRIES ]; do
  ASSIGNMENT=$(az role assignment list --assignee "$PRINCIPAL_ID" --scope "$SERVICEBUS_SCOPE" \
    --query "[?roleDefinitionId=='$ROLE_DEFINITION_ID'] | length(@)" -o tsv)
  if [ "$ASSIGNMENT" != "0" ] && [ -n "$ASSIGNMENT" ]; then
    echo "Event Grid managed identity role assignment is visible after $((RETRY * 10))s, proceeding."
    exit 0
  fi
  RETRY=$((RETRY + 1))
  echo "Role assignment not yet visible, waiting 10s for RBAC propagation (attempt $RETRY/$MAX_RETRIES)..."
  sleep 10
done
echo "ERROR: role assignment did not become visible after $((MAX_RETRIES * 10))s." >&2
exit 1
'''
  }
  dependsOn: [
    eventGridServiceBusSenderRole
    eventGridRoleAssignmentReaderRole
  ]
}

resource eventGridSubscription 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2022-06-15' = if (scanServiceSubscriptionBool && !useExistingEventGridSystemTopic) {
  parent: eventGridTopic
  name: eventGridSubscriptionName
  properties: {
    deliveryWithResourceIdentity: {
      identity: {
        type: 'SystemAssigned'
      }
      destination: {
        endpointType: 'ServiceBusQueue'
        properties: {
          resourceId: functionEventQueue.id
        }
      }
    }
    filter: {
      includedEventTypes: [
        'Microsoft.Resources.ResourceWriteSuccess'
        'Microsoft.Resources.ResourceDeleteSuccess'
      ]
      advancedFilters: [
        {
          operatorType: 'StringContains'
          key: 'data.operationName'
          values: [
            'Microsoft.Web/sites/write'
            'Microsoft.Web/sites/delete'
            'Microsoft.Web/sites/extensions/write'
          ]
        }
        {
          operatorType: 'StringContains'
          key: 'data.resourceUri'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
      ]
    }
    eventDeliverySchema: 'CloudEventSchemaV1_0'
    retryPolicy: {
      maxDeliveryAttempts: 30
      eventTimeToLiveInMinutes: 1440
    }
  }
  dependsOn: [
    eventGridServiceBusSenderRole
    eventGridRbacPropagationCheck
  ]
}

module existingEventGridSubscription 'qualys-cs-existing-event-grid-subscription.bicep' = if (scanServiceSubscriptionBool && useExistingEventGridSystemTopic) {
  name: 'qualys-existing-eventgrid-subscription-${uniqueString(existingEventGridSystemTopicResourceId, functionEventQueue.id)}'
  scope: resourceGroup(existingEventGridSystemTopicResourceIdParts[4])
  params: {
    eventGridTopicName: existingEventGridSystemTopicResourceIdParts[8]
    eventGridSubscriptionName: eventGridSubscriptionName
    functionEventQueueResourceId: functionEventQueue.id
  }
}

// ============================================================
// Metric Alerts
// ============================================================

resource queueDepthAlert 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'qualys-azure-function-events-queue-depth'
  location: 'global'
  properties: {
    description: 'Alert when Service Bus queue has too many messages'
    severity: 2
    enabled: true
    scopes: [
      serviceBusNamespace.id
    ]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT5M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'QueueDepthCriteria'
          criterionType: 'StaticThresholdCriterion'
          metricName: 'ActiveMessages'
          operator: 'GreaterThan'
          threshold: 100
          timeAggregation: 'Average'
        }
      ]
    }
  }
  dependsOn: [
    functionEventQueue
  ]
}

resource dlqAlert 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'qualys-azure-function-events-dlq-messages'
  location: 'global'
  properties: {
    description: 'Alert when messages appear in the dead-letter queue'
    severity: 1
    enabled: true
    scopes: [
      serviceBusNamespace.id
    ]
    evaluationFrequency: 'PT1M'
    windowSize: 'PT1M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name: 'DLQCriteria'
          criterionType: 'StaticThresholdCriterion'
          metricName: 'DeadLetteredMessages'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          timeAggregation: 'Average'
        }
      ]
    }
  }
  dependsOn: [
    functionEventQueue
  ]
}

// ============================================================
// Outputs
// ============================================================

output functionEventQueueId string = functionEventQueue.id
output onboardingQueueId string = onboardingQueue.id
output serviceBusNamespace string = '${serviceBusNamespaceName}.servicebus.windows.net'
output serviceBusNamespaceName string = serviceBusNamespaceName
output cosmosDbEndpoint string = cosmosAccount.properties.documentEndpoint
output cloudOperatorIdentityClientId string = managedIdentity.properties.clientId
output cloudOperatorIdentityPrincipalId string = managedIdentity.properties.principalId
output containerAppName string = containerAppName
output serviceSubscriptionId string = resolvedSubscriptionId
