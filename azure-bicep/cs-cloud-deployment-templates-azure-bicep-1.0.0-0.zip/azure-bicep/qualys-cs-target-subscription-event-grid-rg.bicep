metadata description = 'Cloud-Operator Target Subscription Event Grid Resources (resource-group scoped)'
metadata version = '1.0.0-0'

targetScope = 'resourceGroup'

// ============================================================
// Parameters
// ============================================================

@description('Target Azure Subscription ID where the Event Grid system topic is created.')
param targetSubscriptionId string

@description('Resource ID of the Service Bus queue in the service subscription that receives Function App events.')
param functionEventQueueResourceId string

@description('Resource ID of an existing subscription-level Event Grid system topic to reuse instead of creating a new one. Azure allows only one system topic per subscription source, so if one already exists (e.g. auto-created in a Default-EventGrid resource group), set this instead of letting this module create a new one.')
param existingEventGridSystemTopicResourceId string = ''

// ============================================================
// Variables
// ============================================================

var eventGridTopicName = 'qualys-azure-function-events-topic'
var eventGridSubName = 'qualys-azure-function-events-sub-to-service'
var useExistingEventGridSystemTopic = !empty(existingEventGridSystemTopicResourceId)
var existingEventGridSystemTopicResourceIdParts = split(existingEventGridSystemTopicResourceId, '/')

// Queue resource ID shape:
// /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.ServiceBus/namespaces/{ns}/queues/{queue}
// -> [2] service subscription, [4] service resource group, [8] namespace name.
// Only used on the "create our own topic" path below (see serviceBusSenderRole).
var functionEventQueueResourceIdParts = split(functionEventQueueResourceId, '/')
var serviceSubscriptionId = functionEventQueueResourceIdParts[2]
var serviceBusResourceGroupName = functionEventQueueResourceIdParts[4]
var serviceBusNamespaceName = functionEventQueueResourceIdParts[8]

// ============================================================
// Event Grid System Topic
// ============================================================

resource eventGridTopic 'Microsoft.EventGrid/systemTopics@2022-06-15' = if (!useExistingEventGridSystemTopic) {
  name: eventGridTopicName
  location: 'global'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    source: '/subscriptions/${targetSubscriptionId}'
    topicType: 'Microsoft.Resources.Subscriptions'
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysAzureFunctionEventsForwarding'
  }
}

// ============================================================
// Cross-subscription grant: topic identity -> Azure Service Bus Data Sender
// on the SERVICE subscription's Service Bus namespace
// ============================================================
// The event subscription below delivers with the topic's system-assigned
// identity and Event Grid validates that permission synchronously at create
// time, so the grant must exist first. The namespace lives in the service
// subscription, hence the cross-scope module (same pattern as acrPullRole in
// qualys-cs-service-account-scanning.bicep). Requires
// Microsoft.Authorization/roleAssignments/write on that namespace.
//
// Only applies here, when this template creates its OWN new system topic —
// NOT on the "reuse an existing topic" path below, where the existing topic's
// identity (if any) must already be granted this role outside of Terraform
// (see README, "Manual step: Event Grid -> Service Bus RBAC").

module serviceBusSenderRole 'qualys-cs-target-service-bus-sender-role.bicep' = if (!useExistingEventGridSystemTopic) {
  name: 'qualys-eventgrid-sb-sender-role-${uniqueString(targetSubscriptionId, functionEventQueueResourceId)}'
  scope: resourceGroup(serviceSubscriptionId, serviceBusResourceGroupName)
  params: {
    serviceBusNamespaceName: serviceBusNamespaceName
    principalId: eventGridTopic!.identity.principalId
  }
}

// Azure RBAC role assignments succeed as soon as the write completes, but the
// permission can take a couple of minutes to replicate, and Event Grid checks
// it immediately when the subscription is created ("Managed Identity
// Authorization Error", aka.ms/egmsivalidation). Unlike the service template's
// eventGridRbacPropagationCheck there is no managed identity in this scope that
// could poll the service namespace, so this settles for a fixed delay (same as
// the Terraform module's time_sleep). The README's retry loop covers the
// residual race.
resource eventGridRbacPropagationDelay 'Microsoft.Resources/deploymentScripts@2020-10-01' = if (!useExistingEventGridSystemTopic) {
  name: 'qualys-eventgrid-rbac-delay-${uniqueString(targetSubscriptionId, functionEventQueueResourceId)}'
  location: resourceGroup().location
  kind: 'AzureCLI'
  properties: {
    azCliVersion: '2.50.0'
    retentionInterval: 'PT1H'
    cleanupPreference: 'OnSuccess'
    timeout: 'PT10M'
    scriptContent: 'echo "Waiting 60s for the Service Bus Data Sender role assignment to propagate..."; sleep 60'
  }
  dependsOn: [
    serviceBusSenderRole
  ]
}

// ============================================================
// Event Grid Subscription -> Service Bus Queue (cross-subscription)
// ============================================================

resource eventGridSubscription 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2022-06-15' = if (!useExistingEventGridSystemTopic) {
  parent: eventGridTopic
  name: eventGridSubName
  properties: {
    deliveryWithResourceIdentity: {
      identity: {
        type: 'SystemAssigned'
      }
      destination: {
        endpointType: 'ServiceBusQueue'
        properties: {
          resourceId: functionEventQueueResourceId
        }
      }
    }
    filter: {
      includedEventTypes: [
        'Microsoft.Resources.ResourceWriteSuccess'
        'Microsoft.Resources.ResourceDeleteSuccess'
      ]
      advancedFilters: [
        {
          operatorType: 'StringContains'
          key: 'data.resourceUri'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
        {
          operatorType: 'StringContains'
          key: 'subject'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
      ]
    }
    eventDeliverySchema: 'CloudEventSchemaV1_0'
    retryPolicy: {
      maxDeliveryAttempts: 30
      eventTimeToLiveInMinutes: 1440
    }
  }
  dependsOn: [
    serviceBusSenderRole
    eventGridRbacPropagationDelay
  ]
}

module existingEventGridSubscription 'qualys-cs-target-existing-event-grid-subscription.bicep' = if (useExistingEventGridSystemTopic) {
  name: 'qualys-existing-eventgrid-subscription-${uniqueString(existingEventGridSystemTopicResourceId, functionEventQueueResourceId)}'
  scope: resourceGroup(existingEventGridSystemTopicResourceIdParts[4])
  params: {
    eventGridTopicName: existingEventGridSystemTopicResourceIdParts[8]
    eventGridSubscriptionName: eventGridSubName
    functionEventQueueResourceId: functionEventQueueResourceId
  }
}

// ============================================================
// Outputs
// ============================================================

output eventGridTopicPrincipalId string = useExistingEventGridSystemTopic ? existingEventGridSubscription!.outputs.eventGridTopicPrincipalId : eventGridTopic!.identity.principalId
