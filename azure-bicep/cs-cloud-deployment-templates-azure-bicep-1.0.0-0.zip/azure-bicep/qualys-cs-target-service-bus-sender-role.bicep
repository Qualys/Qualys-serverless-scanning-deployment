metadata description = 'Cloud-Operator Target Subscription: grant the target Event Grid system topic identity "Azure Service Bus Data Sender" on the SERVICE subscription Service Bus namespace (cross-subscription delivery)'
metadata version = '1.0.0-0'

// Deployed by qualys-cs-target-subscription-event-grid-rg.bicep, ONLY when it
// creates its own system topic (never for a reused existing topic — see that
// file's "Existing system topic path"), with
// scope: resourceGroup(<service subscription>, <service Service Bus resource group>),
// the same cross-scope pattern qualys-cs-service-account-scanning.bicep uses
// for qualys-cs-acr-pull-role.bicep.
targetScope = 'resourceGroup'

@description('Name of the Service Bus namespace (in this resource group) that owns the Function App events queue.')
param serviceBusNamespaceName string

@description('Principal ID of the Event Grid system topic system-assigned identity that delivers to the queue.')
param principalId string

resource serviceBusNamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespaceName
}

// Azure Service Bus Data Sender (69a216fc-b8fb-44d8-bc22-1f3c2cd27a39) — same
// role the service template grants its own topic (eventGridServiceBusSenderRole).
resource serviceBusDataSenderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(serviceBusNamespace.id, principalId, 'ServiceBusDataSender')
  scope: serviceBusNamespace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

output roleAssignmentId string = serviceBusDataSenderRole.id
