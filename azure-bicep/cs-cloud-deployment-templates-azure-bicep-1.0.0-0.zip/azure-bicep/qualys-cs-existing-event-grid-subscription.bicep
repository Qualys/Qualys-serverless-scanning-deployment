targetScope = 'resourceGroup'

param eventGridTopicName string
param eventGridSubscriptionName string
param functionEventQueueResourceId string

resource existingEventGridTopic 'Microsoft.EventGrid/systemTopics@2022-06-15' existing = {
  name: eventGridTopicName
}

resource eventGridSubscription 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2022-06-15' = {
  parent: existingEventGridTopic
  name: eventGridSubscriptionName
  properties: {
    destination: {
      endpointType: 'ServiceBusQueue'
      properties: {
        resourceId: functionEventQueueResourceId
      }
    }
    filter: {
      includedEventTypes: [
        'Microsoft.Resources.ResourceWriteSuccess'
        'Microsoft.Resources.ResourceDeleteSuccess'
      ]
      advancedFilters: [
        {
          operatorType: 'StringContains'
          key: 'data.operationName'
          values: [
            'Microsoft.Web/sites/write'
            'Microsoft.Web/sites/delete'
            'Microsoft.Web/sites/extensions/write'
          ]
        }
        {
          operatorType: 'StringContains'
          key: 'data.resourceUri'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
      ]
    }
    eventDeliverySchema: 'CloudEventSchemaV1_0'
    retryPolicy: {
      maxDeliveryAttempts: 30
      eventTimeToLiveInMinutes: 1440
    }
  }
}
