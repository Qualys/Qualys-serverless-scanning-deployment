metadata description = 'Cloud-Operator Subscription-Scoped Role Assignments for Managed Identity'
metadata version = '1.0.0-0'

targetScope = 'subscription'

@description('Principal ID of the managed identity to assign roles to')
param principalId string

@description('Subscription ID for role assignment scoping')
param subscriptionId string

resource readerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(subscriptionId, principalId, 'Reader')
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'acdd72a7-3385-48ef-bd42-f606fba81ae7')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

resource websiteContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(subscriptionId, principalId, 'WebsiteContributor')
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'de139f84-1756-47ae-9be6-808fbbe84772')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

// Storage Blob Data Reader (2a2b9908-6ea1-4ae2-8e65-a410df84e7d1) is required
// for the scanner to list/read blobs in storage accounts it discovers while
// walking the target subscription. The management-plane Reader role only
// permits enumerating storage accounts, not data-plane blob access, which
// results in 403 AuthorizationPermissionMismatch when the scanner attempts
// to list blobs (e.g. in the qualysnotif deployments container).
resource storageBlobDataReaderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(subscriptionId, principalId, 'StorageBlobDataReader')
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '2a2b9908-6ea1-4ae2-8e65-a410df84e7d1')
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}
