metadata description = 'Cloud-Operator Target Subscription: Onboarding notifier Function App that registers the target subscription in Cosmos DB and triggers a backfill scan of existing Function Apps'
metadata version = '1.0.0-0'

targetScope = 'resourceGroup'

// ============================================================
// Parameters
// ============================================================

@description('Azure Subscription ID of the service subscription where the scanning infrastructure (Service Bus, Cosmos DB, cloud-operator) is deployed')
param serviceSubscriptionId string

@description('Azure region where the service subscription stack is deployed (e.g., eastus, westus2)')
param serviceSubscriptionRegion string

@secure()
@description('Send-only connection string for the service subscription onboarding queue')
param onboardingQueueConnectionString string

@description('Primary Azure region for all resources. Defaults to the resource group location.')
param location string = resourceGroup().location

// ============================================================
// Variables
// ============================================================

var targetSubscriptionId = subscription().subscriptionId
var isDifferentSubscription = targetSubscriptionId != serviceSubscriptionId

// The notifier is deployed into the target resource group, so resourceGroup().name
// is the resource group name. This is stored in the onboarding message so
// the cloud-operator can check its existence during reconciliation.
var resourceGroupName = resourceGroup().name

var onboardingQueueName = 'qualys-onboarding-events'

var notifierAppName = 'qualys-notifier-flex-${uniqueString(targetSubscriptionId, resourceGroup().id)}'
var notifierIdentityName = 'qualys-notifier-id-${uniqueString(targetSubscriptionId, resourceGroup().id)}'
var notifierAppServicePlanName = 'qualys-notifier-plan-flex-${uniqueString(targetSubscriptionId, resourceGroup().id)}'
var notifierStorageAccountName = 'qualysnotif${uniqueString(resourceGroup().id)}'
var deploymentContainerName = 'qualys-deployments'

// ============================================================
// Managed Identity
// ============================================================

resource notifierIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = if (isDifferentSubscription) {
  name: notifierIdentityName
  location: location
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysTargetSubscriptionOnboarding'
  }
}

// ============================================================
// App Service Plan (conditional on isDifferentSubscription)
// ============================================================

resource notifierAppServicePlan 'Microsoft.Web/serverfarms@2024-04-01' = if (isDifferentSubscription) {
  name: notifierAppServicePlanName
  location: location
  kind: 'functionapp'
  sku: {
    name: 'FC1'
    tier: 'FlexConsumption'
  }
  properties: {
    reserved: true
  }
}

// ============================================================
// Storage Account (conditional on isDifferentSubscription)
// ============================================================

resource notifierStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = if (isDifferentSubscription) {
  name: notifierStorageAccountName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
  }
}

// ============================================================
// Deployment Blob Container (conditional on isDifferentSubscription)
// ============================================================

resource deploymentContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = if (isDifferentSubscription) {
  name: '${notifierStorageAccountName}/default/${deploymentContainerName}'
  properties: {
    publicAccess: 'None'
  }
  dependsOn: [
    notifierStorage
  ]
}

// ============================================================
// Storage Blob Data Owner Role Assignment (conditional on isDifferentSubscription)
// ============================================================

resource storageBlobDataOwnerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = if (isDifferentSubscription) {
  name: guid(notifierStorage.id, notifierIdentity!.id, 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b')
  scope: notifierStorage
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b')
    principalId: notifierIdentity!.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ============================================================
// Function App (conditional on isDifferentSubscription)
// ============================================================

resource notifierApp 'Microsoft.Web/sites@2024-04-01' = if (isDifferentSubscription) {
  name: notifierAppName
  location: location
  kind: 'functionapp,linux'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${notifierIdentity!.id}': {}
    }
  }
  properties: {
    serverFarmId: notifierAppServicePlan!.id
    functionAppConfig: {
      deployment: {
        storage: {
          type: 'blobContainer'
          value: '${notifierStorage!.properties.primaryEndpoints.blob}${deploymentContainerName}'
          authentication: {
            type: 'UserAssignedIdentity'
            userAssignedIdentityResourceId: notifierIdentity!.id
          }
        }
      }
      runtime: {
        name: 'python'
        version: '3.11'
      }
      scaleAndConcurrency: {
        maximumInstanceCount: 100
        instanceMemoryMB: 2048
      }
    }
    siteConfig: {
      appSettings: [
        {
          name: 'AzureWebJobsStorage__accountName'
          value: notifierStorageAccountName
        }
        {
          name: 'AzureWebJobsStorage__credential'
          value: 'managedidentity'
        }
        {
          name: 'AzureWebJobsStorage__clientId'
          value: notifierIdentity!.properties.clientId
        }
        {
          name: 'TARGET_SUBSCRIPTION_ID'
          value: targetSubscriptionId
        }
        {
          name: 'RESOURCE_GROUP_NAME'
          value: resourceGroupName
        }
        {
          name: 'SERVICE_SUBSCRIPTION_ID'
          value: serviceSubscriptionId
        }
        {
          name: 'SERVICE_SUBSCRIPTION_REGION'
          value: serviceSubscriptionRegion
        }
        {
          name: 'SERVICE_BUS_CONNECTION_STRING'
          value: onboardingQueueConnectionString
        }
        {
          name: 'ONBOARDING_QUEUE_NAME'
          value: onboardingQueueName
        }
        {
          name: 'AZURE_CLIENT_ID'
          value: notifierIdentity!.properties.clientId
        }
      ]
      ftpsState: 'Disabled'
      minTlsVersion: '1.2'
    }
  }
  tags: {
    ManagedBy: 'Bicep'
    Purpose: 'QualysTargetSubscriptionOnboarding'
  }
  dependsOn: [
    deploymentContainer
    storageBlobDataOwnerRole
  ]
}

// ============================================================
// Function Code Deployment via blob container (Flex Consumption)
// Flex Consumption does not support inline function definitions via
// Microsoft.Web/sites/functions. Code must be deployed as a zip package
// to the blob container specified in functionAppConfig.deployment.storage.
// ============================================================

resource functionDeployment 'Microsoft.Resources/deploymentScripts@2020-10-01' = if (isDifferentSubscription) {
  name: 'qualys-function-deploy-${uniqueString(targetSubscriptionId, resourceGroup().id)}'
  location: location
  kind: 'AzureCLI'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${notifierIdentity!.id}': {}
    }
  }
  properties: {
    azCliVersion: '2.50.0'
    retentionInterval: 'PT1H'
    cleanupPreference: 'OnSuccess'
    environmentVariables: [
      {
        name: 'STORAGE_ACCOUNT_NAME'
        value: notifierStorageAccountName
      }
      {
        name: 'CONTAINER_NAME'
        value: deploymentContainerName
      }
      {
        name: 'AZURE_CLIENT_ID'
        value: notifierIdentity!.properties.clientId
      }
    ]
    scriptContent: '''#!/bin/bash
set -e

echo "Deploying function code to Flex Consumption deployment storage"

mkdir -p /tmp/pkg/onboarding-notifier

cat > /tmp/pkg/host.json << 'HOSTJSON'
{
  "version": "2.0",
  "logging": {
    "logLevel": {
      "default": "Information"
    }
  }
}
HOSTJSON

cat > /tmp/pkg/onboarding-notifier/__init__.py << 'PYCODE'
import os
import json
import logging
import azure.functions as func
from azure.servicebus.aio import ServiceBusClient
from azure.servicebus import ServiceBusMessage

async def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Qualys target-subscription onboarding notifier triggered')
    try:
        body = req.get_json() or {}
        event_type = body.get('eventType', 'Create')
        if event_type == 'Delete':
            return func.HttpResponse(
                json.dumps({"status": "SUCCESS"}),
                status_code=200,
                mimetype='application/json'
            )
        target_subscription_id = os.environ['TARGET_SUBSCRIPTION_ID']
        resource_group_name = os.environ.get('RESOURCE_GROUP_NAME', '')
        service_subscription_region = os.environ['SERVICE_SUBSCRIPTION_REGION']
        connection_string = os.environ['SERVICE_BUS_CONNECTION_STRING']
        queue_name = os.environ['ONBOARDING_QUEUE_NAME']
        all_regions = body.get('allRegions', service_subscription_region)
        message_body = json.dumps({
            "source": "qualys.target-subscription",
            "detail-type": "TargetSubscriptionOnboarded",
            "account": target_subscription_id,
            "detail": {
                "subscriptionId": target_subscription_id,
                "regions": [r.strip() for r in all_regions.split(',') if r.strip()],
                "requestType": event_type,
                "deploymentName": body.get('deploymentName', ''),
                "resourceGroupName": resource_group_name
            }
        })
        async with ServiceBusClient.from_connection_string(connection_string) as client:
            async with client.get_queue_sender(queue_name) as sender:
                await sender.send_messages(ServiceBusMessage(message_body))
        logging.info(f'Sent onboarding notification for subscription {target_subscription_id}')
        return func.HttpResponse(
            json.dumps({"status": "SUCCESS"}),
            status_code=200,
            mimetype='application/json'
        )
    except Exception as error:
        logging.error(f'Onboarding notifier failed: {error}')
        return func.HttpResponse(
            json.dumps({"status": "FAILED", "error": str(error)}),
            status_code=500,
            mimetype='application/json'
        )
PYCODE

cat > /tmp/pkg/onboarding-notifier/function.json << 'FUNCJSON'
{
  "scriptFile": "__init__.py",
  "bindings": [
    {
      "authLevel": "function",
      "type": "httpTrigger",
      "direction": "in",
      "name": "req",
      "methods": ["post"],
      "route": "onboarding"
    },
    {
      "type": "http",
      "direction": "out",
      "name": "$return"
    }
  ]
}
FUNCJSON

cat > /tmp/pkg/requirements.txt << 'REQS'
azure-functions
azure-servicebus>=7.0.0
REQS

cd /tmp/pkg
zip -r /tmp/functionapp.zip .
echo "Function package created"

# Wait for RBAC propagation, then upload zip to deployment container
MAX_RETRIES=5
RETRY=0
while [ $RETRY -lt $MAX_RETRIES ]; do
  if az storage blob upload \
    --account-name "$STORAGE_ACCOUNT_NAME" \
    --container-name "$CONTAINER_NAME" \
    --name functionapp.zip \
    --file /tmp/functionapp.zip \
    --auth-mode login \
    --overwrite; then
    echo "Function package uploaded successfully"
    break
  else
    RETRY=$((RETRY + 1))
    echo "Upload attempt $RETRY failed, waiting 15s for RBAC propagation..."
    sleep 15
  fi
done

if [ $RETRY -eq $MAX_RETRIES ]; then
  echo "Failed to upload function package after $MAX_RETRIES attempts"
  exit 1
fi

echo "Function code deployment complete - Flex Consumption will auto-sync from blob container"
'''
  }
  dependsOn: [
    notifierApp
    deploymentContainer
    storageBlobDataOwnerRole
  ]
}

// ============================================================
// Onboarding Trigger (conditional on isDifferentSubscription)
// ============================================================

resource onboardingTrigger 'Microsoft.Resources/deploymentScripts@2020-10-01' = if (isDifferentSubscription) {
  name: 'qualys-onboarding-trigger-${uniqueString(targetSubscriptionId, resourceGroup().id)}'
  location: location
  kind: 'AzureCLI'
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${notifierIdentity!.id}': {}
    }
  }
  properties: {
    azCliVersion: '2.50.0'
    retentionInterval: 'PT1H'
    cleanupPreference: 'OnSuccess'
    environmentVariables: [
      {
        name: 'ONBOARDING_QUEUE_CONNECTION_STRING'
        secureValue: onboardingQueueConnectionString
      }
      {
        name: 'TARGET_SUBSCRIPTION_ID'
        value: targetSubscriptionId
      }
      {
        name: 'RESOURCE_GROUP_NAME'
        value: resourceGroupName
      }
      {
        name: 'TARGET_LOCATION'
        value: location
      }
    ]
    scriptContent: '''
#!/bin/bash
echo "Triggering onboarding notification for subscription $TARGET_SUBSCRIPTION_ID"

# Send onboarding message directly to Service Bus queue (bypassing Function App HTTP endpoint)
pip install azure-servicebus -q 2>/dev/null

python3 -c "
import asyncio, json, os
from azure.servicebus.aio import ServiceBusClient
from azure.servicebus import ServiceBusMessage

async def main():
    conn_str = os.environ['ONBOARDING_QUEUE_CONNECTION_STRING']
    queue_name = '${onboardingQueueName}'
    for part in conn_str.split(';'):
        part = part.strip()
        if part.lower().startswith('entitypath='):
            queue_name = part.split('=', 1)[1]
            break
    sub_id = os.environ['TARGET_SUBSCRIPTION_ID']
    loc = os.environ['TARGET_LOCATION']
    rg_name = os.environ.get('RESOURCE_GROUP_NAME', '')
    msg = json.dumps({
        'source': 'qualys.target-subscription',
        'detail-type': 'TargetSubscriptionOnboarded',
        'account': sub_id,
        'detail': {
            'subscriptionId': sub_id,
            'regions': [loc],
            'requestType': 'Create',
            'deploymentName': 'qualys-target-subscription-resources',
            'resourceGroupName': rg_name
        }
    })
    async with ServiceBusClient.from_connection_string(conn_str) as client:
        async with client.get_queue_sender(queue_name) as sender:
            await sender.send_messages(ServiceBusMessage(msg))
    print('Onboarding message sent successfully')

asyncio.run(main())
"

if [ $? -eq 0 ]; then
  echo "Onboarding notification sent successfully"
else
  echo "Failed to send onboarding notification"
  exit 1
fi
'''
  }
  dependsOn: [
    functionDeployment
  ]
}

// ============================================================
// Outputs
// ============================================================

output notifierIdentityPrincipalId string = isDifferentSubscription ? notifierIdentity!.properties.principalId : ''
