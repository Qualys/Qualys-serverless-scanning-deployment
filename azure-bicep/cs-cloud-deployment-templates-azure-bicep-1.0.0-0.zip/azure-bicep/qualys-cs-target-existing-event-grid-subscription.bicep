metadata description = 'Cloud-Operator Target Subscription: Event Grid subscription on an existing subscription-level system topic (cross-subscription delivery)'
metadata version = '1.0.0-0'

targetScope = 'resourceGroup'

// ============================================================
// Parameters
// ============================================================

@description('Name of the existing Event Grid system topic (subscription-level source) to attach the event subscription to.')
param eventGridTopicName string

@description('Name of the Event Grid subscription to create on the existing system topic.')
param eventGridSubscriptionName string

@description('Resource ID of the Service Bus queue in the service subscription that receives Function App events.')
param functionEventQueueResourceId string

// ============================================================
// Existing Event Grid System Topic
// ============================================================

resource existingEventGridTopic 'Microsoft.EventGrid/systemTopics@2022-06-15' existing = {
  name: eventGridTopicName
}

// ============================================================
// Event Grid Subscription -> Service Bus Queue (cross-subscription)
// ============================================================

resource eventGridSubscription 'Microsoft.EventGrid/systemTopics/eventSubscriptions@2022-06-15' = {
  parent: existingEventGridTopic
  name: eventGridSubscriptionName
  properties: {
    destination: {
      endpointType: 'ServiceBusQueue'
      properties: {
        resourceId: functionEventQueueResourceId
      }
    }
    filter: {
      includedEventTypes: [
        'Microsoft.Resources.ResourceWriteSuccess'
        'Microsoft.Resources.ResourceDeleteSuccess'
      ]
      advancedFilters: [
        {
          operatorType: 'StringContains'
          key: 'data.resourceUri'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
        {
          operatorType: 'StringContains'
          key: 'subject'
          values: [
            '/providers/Microsoft.Web/sites/'
          ]
        }
      ]
    }
    eventDeliverySchema: 'CloudEventSchemaV1_0'
    retryPolicy: {
      maxDeliveryAttempts: 30
      eventTimeToLiveInMinutes: 1440
    }
  }
}

// ============================================================
// Outputs
// ============================================================

@description('Placeholder output. The existing system topic\'s managed identity must already be granted Azure Service Bus Data Sender on the service queue outside this template, so this module does not create or return a principal ID.')
output eventGridTopicPrincipalId string = ''
