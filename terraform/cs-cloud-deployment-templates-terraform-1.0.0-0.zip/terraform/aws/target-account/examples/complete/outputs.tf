output "cross_account_role_arn" {
  description = "Register this role ARN for the target account in the service account"
  value       = module.target_account.cross_account_role_arn
}

output "eventbridge_rule_arn" {
  value = module.target_account.eventbridge_rule_arn
}
