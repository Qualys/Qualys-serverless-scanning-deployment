variable "primary_region" {
  type        = string
  description = "Primary deploy region of the target account."
  default     = "us-east-1"
}

variable "aws_profile" {
  type        = string
  description = "AWS CLI profile to use for the target account (applies to every provider block, including secondary regions). Leave empty to use the ambient default credential chain (default profile, AWS_PROFILE env var, instance role, etc.)."
  default     = ""
}

variable "secondary_regions" {
  type        = list(string)
  description = "Secondary regions to forward events from. The root module deploys a CloudFormation StackSet instance into each region."
  default     = ["us-west-2"]
}

variable "service_account_id" {
  type        = string
  description = "AWS account ID of the service account."
}

variable "service_account_region" {
  type        = string
  description = "Region where the service account stack is deployed (NOT necessarily this account's primary region)."
}

variable "enable_fargate_inventory" {
  type        = bool
  description = "Forward ECS Task State Change events to the service account."
  default     = true
}

variable "enable_lambda_scanning" {
  type        = bool
  description = "Enable Lambda function scanning. Set false to disable Lambda event forwarding."
  default     = true
}

variable "deployment_name" {
  type        = string
  description = "Deployment name — the CloudFormation stack-name equivalent. Sent as stackName in the onboarding notification and used as the per-region DLQ prefix."
  default     = "cloud-scanning-target"
}
