# Complete target-account deployment: cross-account role + primary-region
# forwarding, plus any secondary regions deployed via CloudFormation StackSet.

module "target_account" {
  source = "../.."

  service_account_id     = var.service_account_id
  service_account_region = var.service_account_region
  # Reported in the onboarding notification; the root module deploys the
  # per-region EventBridge forwarding rules from this list.
  secondary_regions        = var.secondary_regions
  deployment_name          = var.deployment_name
  enable_fargate_inventory = var.enable_fargate_inventory
  enable_lambda_scanning   = var.enable_lambda_scanning

  tags = {
    Project = "qualys-cloud-operator"
  }
}

# Secondary regions are handled inside the root module via
# aws_cloudformation_stack_set / aws_cloudformation_stack_set_instance.
# No extra module calls or provider aliases are needed.
