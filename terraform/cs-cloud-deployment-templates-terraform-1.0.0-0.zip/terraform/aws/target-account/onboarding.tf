# ========================================
# Target-account onboarding notifier
# ========================================
# Terraform port of the TargetAccountOnboardingNotifier custom resource in
# cloudformation/qualys-cs-target-account-scanning.yaml. Sends ONE
# TargetAccountOnboarded message to the service-account qualys-onboarding-events
# queue on create and again whenever the region set changes, so the account
# enters the onboarded-accounts table and existing workloads are backfilled
# without waiting for an organic event. Same-account deploys are covered by the
# service-account stack (CFN ShouldNotify condition).

resource "aws_iam_role" "onboarding_notifier" {
  count = local.should_notify ? 1 : 0

  name        = "qualys-cloud-scanning-notifier-role"
  description = "Role for the onboarding notifier Lambda to send to the service-account onboarding queue"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "onboarding_notifier" {
  count = local.should_notify ? 1 : 0

  name = "SendOnboardingMessage"
  role = aws_iam_role.onboarding_notifier[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "sqs:SendMessage"
        Resource = local.onboarding_queue_arn
      },
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "arn:${local.partition}:logs:${local.region}:${local.account_id}:log-group:/aws/lambda/qualys-target-account-onboarding-notifier:*"
      },
    ]
  })
}

data "archive_file" "onboarding_notifier" {
  count = local.should_notify ? 1 : 0

  type        = "zip"
  output_path = "${path.module}/builds/onboarding-notifier.zip"

  source {
    filename = "index.py"
    # Invoked by aws_lambda_invocation (lifecycle_scope = CRUD): tf.action
    # create/update/delete maps to the CloudFormation-style requestType the
    # cloud-operator TargetAccountOnboardingHandler expects. The Delete case
    # must still send the notification (mirroring the CFN custom resource,
    # which always forwards event['RequestType'] including 'Delete') — that's
    # what makes the handler remove this account's rows from
    # qualys-onboarded-accounts and qualys-lambda-scan-jobs when the target
    # account's Terraform deployment is destroyed. Skipping it here (as an
    # earlier version of this file did) leaves those rows behind forever.
    content = <<-PY
      import json
      import boto3

      def handler(event, context):
          action = event.get("tf", {}).get("action", "create")
          request_type = {"create": "Create", "update": "Update", "delete": "Delete"}.get(action, "Create")
          msg = {
              "source": "qualys.target-account",
              "detail-type": "TargetAccountOnboarded",
              "account": event["account_id"],
              "detail": {
                  "accountId": event["account_id"],
                  "regions": event["regions"],
                  "stackName": event["stack_name"],
                  "requestType": request_type,
              },
          }
          boto3.client("sqs", region_name=event["service_account_region"]).send_message(
              QueueUrl=event["queue_url"], MessageBody=json.dumps(msg)
          )
          return {"status": "sent", "regions": event["regions"], "requestType": request_type}
    PY
  }
}

resource "aws_lambda_function" "onboarding_notifier" {
  count = local.should_notify ? 1 : 0

  function_name    = "qualys-target-account-onboarding-notifier"
  description      = "Notifies the service account that this target account was onboarded"
  runtime          = "python3.12"
  handler          = "index.handler"
  role             = aws_iam_role.onboarding_notifier[0].arn
  timeout          = 60
  filename         = data.archive_file.onboarding_notifier[0].output_path
  source_code_hash = data.archive_file.onboarding_notifier[0].output_base64sha256

  tags = local.common_tags
}

# Fires on create and re-fires when the input changes (notably the region set).
resource "aws_lambda_invocation" "onboarding_notifier" {
  count = local.should_notify ? 1 : 0

  function_name   = aws_lambda_function.onboarding_notifier[0].function_name
  lifecycle_scope = "CRUD"

  input = jsonencode({
    account_id             = local.account_id
    regions                = local.all_regions
    stack_name             = var.deployment_name
    service_account_region = var.service_account_region
    queue_url              = local.onboarding_queue_url
  })

  depends_on = [aws_iam_role_policy.onboarding_notifier]
}
