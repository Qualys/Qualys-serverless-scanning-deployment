# Target-account module inputs. Mirror the CloudFormation Parameters in
# cloudformation/target-account-scanning.yaml.

variable "service_account_id" {
  type        = string
  description = "AWS account ID of the service account where the cloud-operator infrastructure is deployed."

  validation {
    condition     = can(regex("^\\d{12}$", var.service_account_id))
    error_message = "service_account_id must be a 12-digit AWS account ID."
  }
}

variable "service_account_region" {
  type        = string
  description = "AWS region where the service account stack is deployed (e.g. us-west-2). Used to build the service-account queue and event-bus ARNs."

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]+$", var.service_account_region))
    error_message = "service_account_region must be a valid AWS region name."
  }
}

variable "secondary_regions" {
  type        = list(string)
  description = <<-EOT
    Regions beyond the deploy region this deployment covers. The module deploys a
    CloudFormation StackSet instance into each region to forward Lambda and
    Fargate events to the service-account default event bus. The list is also
    reported in the onboarding notification so the service account backfills
    them.
  EOT
  default     = []
}

variable "deployment_name" {
  type        = string
  description = "Deployment name — the CloudFormation stack-name equivalent. Sent as stackName in the onboarding notification."
  default     = "cloud-scanning-target"
}

variable "enable_fargate_inventory" {
  type        = bool
  description = "Forward ECS Task State Change events from this target account to the service account for the Fargate workload."
  default     = true
}

variable "enable_lambda_scanning" {
  type        = bool
  description = "Enable Lambda function scanning. Set false to disable Lambda event forwarding from this target account (e.g. when running Fargate-only)."
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "Additional tags applied to all resources that support tagging."
  default     = {}
}
