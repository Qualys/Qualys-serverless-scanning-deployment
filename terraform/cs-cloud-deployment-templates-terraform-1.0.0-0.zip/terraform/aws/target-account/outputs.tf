output "cross_account_role_arn" {
  description = "ARN of the cross-account role for Lambda scanning"
  value       = aws_iam_role.cross_account.arn
}

output "service_account_id" {
  description = "Service account ID that can assume the cross-account role"
  value       = var.service_account_id
}

output "eventbridge_rule_arn" {
  description = "ARN of the Lambda-events forwarding rule (null for same-account deploys)"
  value       = local.is_different_account ? aws_cloudwatch_event_rule.lambda_function_events[0].arn : null
}

output "service_account_event_bus_arn" {
  description = "Default event bus ARN in the SERVICE ACCOUNT's region that secondary regions forward to (bus-to-bus hop). Built from service_account_region — the service-account rules that route the forwarded events live there, not in this deploy region."
  value       = "arn:${local.partition}:events:${var.service_account_region}:${var.service_account_id}:event-bus/default"
}
