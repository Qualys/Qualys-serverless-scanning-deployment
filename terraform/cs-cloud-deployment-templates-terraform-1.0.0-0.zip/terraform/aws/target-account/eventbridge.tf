# ========================================
# Lambda function events -> service-account event bus (primary region)
# ========================================
# Only for a DIFFERENT target account; same-account primary capture is handled
# by the service-account stack.
resource "aws_cloudwatch_event_rule" "lambda_function_events" {
  count = local.is_different_account ? 1 : 0

  name        = "qualys-lambda-function-events-to-service-account"
  description = "Capture Lambda function events and forward to the service account event bus"
  state       = var.enable_lambda_scanning ? "ENABLED" : "DISABLED"

  event_pattern = jsonencode({
    source        = ["aws.lambda"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["lambda.amazonaws.com"]
      eventName   = ["CreateFunction20150331", "UpdateFunctionCode20150331v2", "DeleteFunction20150331"]
      errorCode   = [{ exists = false }]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "lambda_function_events" {
  count = local.is_different_account ? 1 : 0

  rule      = aws_cloudwatch_event_rule.lambda_function_events[0].name
  target_id = "ServiceAccountEventBusTarget"
  arn       = local.service_account_event_bus_arn
  role_arn  = aws_iam_role.eventbridge_to_sqs[0].arn
}

# ========================================
# ECS Fargate state change -> service-account event bus (primary region)
# ========================================
# RUNNING-only (imageDigest is resolved by RUNNING). Different account only.
# Bus-to-bus: the service-account qualys-ecs-task-state-change rule re-matches
# the forwarded event and routes it to the Fargate queue in its own region.
resource "aws_cloudwatch_event_rule" "fargate_state_change" {
  count = local.forward_fargate_events ? 1 : 0

  name        = "qualys-ecs-fargate-state-change-to-service-account"
  description = "Forward FARGATE ECS Task State Change (RUNNING) events to the service account event bus"
  state       = "ENABLED"

  event_pattern = jsonencode({
    source        = ["aws.ecs"]
    "detail-type" = ["ECS Task State Change"]
    detail = {
      "$or" = [
        { launchType = ["FARGATE"] },
        { capacityProviderName = ["FARGATE", "FARGATE_SPOT"] },
      ]
      lastStatus    = ["RUNNING"]
      desiredStatus = ["RUNNING"]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "fargate_state_change" {
  count = local.forward_fargate_events ? 1 : 0

  rule      = aws_cloudwatch_event_rule.fargate_state_change[0].name
  target_id = "ServiceAccountEventBusTargetECS"
  arn       = local.service_account_event_bus_arn
  role_arn  = aws_iam_role.eventbridge_to_sqs[0].arn
}

# ========================================
# Forwarding failure alarms (primary region)
# ========================================
# No DLQ on the forwarding rules: both workloads can be replayed from the
# service account (onboarding backfill / daily bulk rescan), so retaining the
# raw event is not worth an SQS queue in every target account and region. What
# matters is NOTICING that forwarding is broken — the usual cause is this
# account missing from the service account's target_account_ids/organization_id,
# which makes PutEvents unauthorized. FailedInvocations counts deliveries that
# EventBridge gave up on permanently.
resource "aws_cloudwatch_metric_alarm" "lambda_forwarding_failed" {
  count = local.is_different_account ? 1 : 0

  alarm_name          = "qualys-lambda-forwarding-failed"
  alarm_description   = "Lambda events are failing to reach the service account event bus (check that this account is onboarded in the service account stack)"
  namespace           = "AWS/Events"
  metric_name         = "FailedInvocations"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 0
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    RuleName = aws_cloudwatch_event_rule.lambda_function_events[0].name
  }

  tags = local.common_tags
}

resource "aws_cloudwatch_metric_alarm" "fargate_forwarding_failed" {
  count = local.forward_fargate_events ? 1 : 0

  alarm_name          = "qualys-fargate-forwarding-failed"
  alarm_description   = "Fargate task events are failing to reach the service account event bus (check that this account is onboarded in the service account stack)"
  namespace           = "AWS/Events"
  metric_name         = "FailedInvocations"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 0
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    RuleName = aws_cloudwatch_event_rule.fargate_state_change[0].name
  }

  tags = local.common_tags
}
