data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition
  region     = data.aws_region.current.region

  # IsDifferentAccount: same-account primary capture is already done by the
  # service-account stack, so the forwarding rules are only for a different account.
  is_different_account = local.account_id != var.service_account_id

  fargate_enabled = var.enable_fargate_inventory

  # Service-account queues have fixed names (contract shared with the CFN
  # templates); ARNs/URLs are built from the service-account id and region.
  onboarding_queue_arn = "arn:${local.partition}:sqs:${var.service_account_region}:${var.service_account_id}:qualys-onboarding-events"
  onboarding_queue_url = "https://sqs.${var.service_account_region}.amazonaws.com/${var.service_account_id}/qualys-onboarding-events"

  # Forwarding target for BOTH Lambda and Fargate events: the service-account
  # default event bus in the SERVICE ACCOUNT's region. Target accounts never
  # write to the service-account SQS queues directly — the service-account rules
  # (qualys-lambda-function-events-target-account / qualys-ecs-task-state-change)
  # route the forwarded events to SQS inside that account.
  service_account_event_bus_arn = "arn:${local.partition}:events:${var.service_account_region}:${var.service_account_id}:event-bus/default"

  # ShouldNotify: same-account onboarding is handled by the service-account stack.
  should_notify = local.is_different_account

  # All regions this deployment covers, reported in the onboarding notification.
  all_regions = concat([local.region], var.secondary_regions)

  # ForwardFargateEvents: primary-region Fargate forwarding (different account only).
  forward_fargate_events = local.is_different_account && local.fargate_enabled

  # NeedsEBToSQSRole: the EventBridge->event-bus role is needed whenever we forward.
  needs_eb_to_sqs_role = local.is_different_account || local.fargate_enabled

  common_tags = merge({ ManagedBy = "qualys-terraform" }, var.tags)
}
