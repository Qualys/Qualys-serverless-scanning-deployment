# ========================================
# Cross-account role assumed by the cloud-operator
# ========================================
resource "aws_iam_role" "cross_account" {
  name        = "QualysCloudOperatorRole"
  description = "Role assumed by cloud-operator to scan Lambda functions"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { AWS = "arn:${local.partition}:iam::${var.service_account_id}:root" }
      Action    = "sts:AssumeRole"
      Condition = {
        StringEquals = { "sts:ExternalId" = var.service_account_id }
      }
    }]
  })

  max_session_duration = 3600

  tags = merge(local.common_tags, {
    Name    = "QualysCloudOperatorRole"
    Purpose = "CloudOperatorLambdaScanning"
  })
}

resource "aws_iam_role_policy" "lambda_scanning" {
  name = "LambdaScanningPolicy"
  role = aws_iam_role.cross_account.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "ListLambdaFunctions"
        Effect   = "Allow"
        Action   = ["lambda:ListFunctions"]
        Resource = "*"
      },
      {
        Sid    = "GetLambdaDetails"
        Effect = "Allow"
        Action = [
          "lambda:GetFunction",
          "lambda:GetFunctionConfiguration",
          "lambda:GetFunctionCodeSigningConfig",
          "lambda:GetPolicy",
        ]
        Resource = "arn:${local.partition}:lambda:*:*:function:*"
      },
      {
        Sid      = "GetLambdaLayers"
        Effect   = "Allow"
        Action   = ["lambda:ListLayerVersions", "lambda:GetLayerVersion"]
        Resource = "arn:${local.partition}:lambda:*:*:layer:*"
      },
      {
        Sid    = "PullECRImages"
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken",
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
          "ecr:DescribeImages",
          "ecr:DescribeRepositories",
        ]
        Resource = "*"
      },
      {
        Sid    = "FargateInventoryCollection"
        Effect = "Allow"
        Action = [
          "ecs:ListClusters",
          "ecs:ListTasks",
          "ecs:DescribeTasks",
          "ecs:DescribeServices",
          "ecs:DescribeTaskDefinition",
          "tag:GetResources",
        ]
        Resource = "*"
      },
    ]
  })
}

# ========================================
# EventBridge -> service-account event bus role
# ========================================
# Role name is retained for backwards compatibility with existing deployments
# even though forwarding is now bus-to-bus rather than direct-to-SQS.
resource "aws_iam_role" "eventbridge_to_sqs" {
  count = local.needs_eb_to_sqs_role ? 1 : 0

  name        = "qualys-cloud-scanning-eventbridge-to-sqs-role"
  description = "Role for EventBridge to send Lambda and Fargate events to the service account event bus"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "events.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = merge(local.common_tags, { Name = "qualys-cloud-scanning-eventbridge-to-sqs-role" })
}

resource "aws_iam_role_policy" "eventbridge_to_sqs" {
  count = local.needs_eb_to_sqs_role ? 1 : 0

  name = "SendToServiceAccountEventBus"
  role = aws_iam_role.eventbridge_to_sqs[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "events:PutEvents"
      Resource = local.service_account_event_bus_arn
    }]
  })
}
