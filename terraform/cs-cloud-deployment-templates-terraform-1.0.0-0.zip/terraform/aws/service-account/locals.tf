data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition
  region     = data.aws_region.current.region

  # UseProvidedServiceAccountId
  service_account_id = var.service_account_id != "" ? var.service_account_id : local.account_id

  has_secondary_regions = length(var.secondary_regions) > 0
  has_target_accounts   = length(var.target_account_ids) > 0
  has_organization_id   = var.organization_id != ""
  organization_ids      = var.organization_id == "" ? [] : [for s in split(",", var.organization_id) : trimspace(s)]

  fargate_inventory_enabled = var.enable_fargate_inventory

  # Disabled-state capture: when a workload is switched off, events that would
  # otherwise be silently dropped from the default bus are captured in a
  # short-retention queue so the drop is observable.
  lambda_scanning_disabled   = !var.enable_lambda_scanning
  fargate_inventory_disabled = !var.enable_fargate_inventory
  any_workload_disabled      = local.lambda_scanning_disabled || local.fargate_inventory_disabled
  # FargateInventoryServiceAccount: enabled AND we scan the service account itself.
  fargate_inventory_service_account = var.enable_fargate_inventory && var.scan_service_account

  # UseVpcConfig: attach the cloud-operator and fargate-inventory Lambda functions
  # to a VPC when subnet_ids is provided.
  use_vpc_config = length(var.subnet_ids) > 0

  # REGIONS env var: deploy region first, then any secondary regions.
  regions_csv = local.has_secondary_regions ? join(",", concat([local.region], var.secondary_regions)) : local.region

  # Fargate dedup + cache tables, created only when Fargate inventory is enabled.
  fargate_tables = local.fargate_inventory_enabled ? {
    dedup   = { name = "qualys-fargate-inventory-dedup", hash_key = "dedup_key" }
    service = { name = "qualys-fargate-service-cache", hash_key = "service_cache_key" }
    taskdef = { name = "qualys-fargate-taskdef-cache", hash_key = "task_definition_arn" }
  } : {}

  common_tags = merge({ ManagedBy = "qualys-terraform" }, var.tags)
}
