# Service-account module inputs. Mirror the CloudFormation Parameters in
# cloudformation/service-account-scanning.yaml so the two stay in lockstep.

variable "service_account_id" {
  type        = string
  description = "AWS account ID where this stack is deployed (service account). Leave empty to auto-detect via the caller identity."
  default     = ""

  validation {
    condition     = var.service_account_id == "" || can(regex("^\\d{12}$", var.service_account_id))
    error_message = "service_account_id must be empty or a 12-digit AWS account ID."
  }
}

variable "cloud_operator_image_uri" {
  type        = string
  description = "ECR image URI for the cloud-operator Lambda (e.g. 123456789012.dkr.ecr.us-east-1.amazonaws.com/cloud-operator:latest)."
}

variable "target_account_ids" {
  type        = list(string)
  description = "Target AWS account IDs to scan (optional; DynamoDB discovery can be used instead)."
  default     = []
}

variable "secondary_regions" {
  type        = list(string)
  description = "Regions beyond the deploy region to capture cross-region events from. Must not include the deploy region. The module deploys a CloudFormation StackSet instance into each region to forward Lambda and Fargate events to the central event bus."
  default     = []
}

variable "qualys_access_token" {
  type        = string
  description = "Qualys access token for qscanner."
  default     = ""
  sensitive   = true
}

variable "qualys_client_id" {
  type        = string
  description = "Optional OAuth client ID for qscanner."
  default     = ""
}

variable "qualys_client_secret" {
  type        = string
  description = "Optional OAuth client secret for qscanner."
  default     = ""
  sensitive   = true
}

variable "qualys_secret_arn" {
  type        = string
  description = "Optional Secrets Manager ARN with Qualys credentials JSON {access_token, client_id, client_secret}. When set it overrides the plaintext qualys_* inputs."
  default     = ""
}

variable "scan_types" {
  type        = string
  description = "Comma-separated scan types passed to qscanner."
  default     = "pkg,fileinsight,aiinsight"
}

variable "proxy" {
  type        = string
  description = "Optional HTTP/HTTPS proxy URL (e.g. http://proxy.example.com:3128)."
  default     = ""
}

variable "ca_certificate" {
  type        = string
  description = "Optional base64-encoded CA certificate."
  default     = ""
  sensitive   = true
}

variable "skip_tls_verify" {
  type        = string
  description = "Skip TLS verification for Qualys API calls (true or false)."
  default     = "false"

  validation {
    condition     = contains(["true", "false"], var.skip_tls_verify)
    error_message = "skip_tls_verify must be 'true' or 'false'."
  }
}

variable "log_level" {
  type        = string
  description = "Log level for the Lambda functions."
  default     = "info"

  validation {
    condition     = contains(["debug", "info", "warn", "error", "fatal"], var.log_level)
    error_message = "log_level must be one of: debug, info, warn, error, fatal."
  }
}

variable "gateway_url" {
  type        = string
  description = "Qualys gateway URL passed to qscanner via --gateway-url (e.g. https://gateway.qg1.apps.qualys.com)."
}

variable "customer_id" {
  type        = string
  description = "Qualys customer/subscription id used in v2.1 inventory events and the X-Customer-Id header. Required for Fargate inventory."
  default     = ""
}

variable "cloud_operator_memory_size" {
  type        = number
  description = "Memory size for the orchestrator Lambda (MB)."
  default     = 2048

  validation {
    condition     = var.cloud_operator_memory_size >= 128 && var.cloud_operator_memory_size <= 10240
    error_message = "cloud_operator_memory_size must be between 128 and 10240."
  }
}

variable "cloud_operator_timeout" {
  type        = number
  description = "Timeout for the orchestrator Lambda (seconds). 900 keeps large-region Fargate bulk-scan units within one invocation."
  default     = 900

  validation {
    condition     = var.cloud_operator_timeout >= 30 && var.cloud_operator_timeout <= 900
    error_message = "cloud_operator_timeout must be between 30 and 900."
  }
}

variable "lambda_sqs_batch_size" {
  type        = number
  description = "Number of SQS messages to process in batch for the Lambda workload queue."
  default     = 1

  validation {
    condition     = var.lambda_sqs_batch_size >= 1 && var.lambda_sqs_batch_size <= 10
    error_message = "lambda_sqs_batch_size must be between 1 and 10."
  }
}

variable "sqs_batch_size" {
  type        = number
  description = "Number of SQS messages to process in batch for the Fargate inventory queue (tuned independently of Lambda scanning)."
  default     = 10

  validation {
    condition     = var.sqs_batch_size >= 1 && var.sqs_batch_size <= 10
    error_message = "sqs_batch_size must be between 1 and 10."
  }
}

variable "lambda_scan_max_concurrency" {
  type        = number
  description = "Maximum concurrency for the Lambda scanning event source mapping (number of simultaneous Lambda invocations processing SQS messages)."
  default     = 50

  validation {
    condition     = var.lambda_scan_max_concurrency >= 1 && var.lambda_scan_max_concurrency <= 1000
    error_message = "lambda_scan_max_concurrency must be between 1 and 1000."
  }
}

variable "cloud_operator_lambda_architecture" {
  type        = string
  description = "Architecture for the Lambda functions."
  default     = "x86_64"

  validation {
    condition     = contains(["x86_64", "arm64"], var.cloud_operator_lambda_architecture)
    error_message = "cloud_operator_lambda_architecture must be x86_64 or arm64."
  }
}

variable "cloud_operator_ephemeral_storage_size" {
  type        = number
  description = "Ephemeral storage (/tmp) size for the orchestrator Lambda (MB)."
  default     = 5120

  validation {
    condition     = var.cloud_operator_ephemeral_storage_size >= 512 && var.cloud_operator_ephemeral_storage_size <= 10240
    error_message = "cloud_operator_ephemeral_storage_size must be between 512 and 10240."
  }
}

variable "scan_service_account" {
  type        = bool
  description = "Scan Lambda functions and Fargate tasks in the service account itself. Set false to only scan target accounts."
  default     = true
}

variable "enable_lambda_scanning" {
  type        = bool
  description = "Enable Lambda function scanning. Set false to run Fargate-only."
  default     = true
}

variable "enable_fargate_inventory" {
  type        = bool
  description = "Enable the ECS Fargate inventory workload (dedicated Lambda, queue, tables, and ECS Task State Change rule)."
  default     = true
}

variable "disabled_event_capture_retention_seconds" {
  type        = number
  description = "Retention for the disabled-scanning capture queue (qualys-events-disabled-capture). Nothing consumes this queue, so messages are kept only long enough to notice and debug that events are arriving while a workload is disabled, then drain automatically (which also lets the depth alarm clear)."
  default     = 259200 # 3 days

  validation {
    condition     = var.disabled_event_capture_retention_seconds >= 60 && var.disabled_event_capture_retention_seconds <= 1209600
    error_message = "disabled_event_capture_retention_seconds must be between 60 and 1209600 (SQS limits)."
  }
}

variable "organization_id" {
  type        = string
  description = "Optional comma-separated list of AWS Organizations IDs (e.g. o-xxxxxxxxxx,o-yyyyyyyyyy). When set, the queue and event-bus policies also allow any org account holding the required role, in addition to (or instead of) target_account_ids."
  default     = ""

  validation {
    condition     = var.organization_id == "" || can(regex("^(o-[a-z0-9]{10,32})(\\s*,\\s*o-[a-z0-9]{10,32})*$", var.organization_id))
    error_message = "organization_id must be empty or a comma-separated list of AWS Organizations IDs (o-xxxxxxxxxx)."
  }
}

variable "enable_cloud_metadata_collection" {
  type        = bool
  description = "Enrich Fargate inventory events with task-definition metadata and resource tags via ECS Describe* APIs. Best-effort; off by default."
  default     = false
}

variable "lambda_log_retention_days" {
  type        = number
  description = "CloudWatch log retention for the Lambda log groups (days)."
  default     = 7
}

variable "vpc_id" {
  type        = string
  description = "Optional. VPC ID to run the cloud-operator and fargate-inventory Lambda functions in (e.g. vpc-0123456789abcdef0). Use this when outbound connections to gateway_url are only allowed from within a specific VPC (e.g. via a NAT gateway, proxy, or firewall egress path). Leave empty to run the Lambda functions outside any VPC (default). Not used directly by any resource; provided for documentation/validation alongside subnet_ids."
  default     = ""
}

variable "subnet_ids" {
  type        = list(string)
  description = "Optional. Subnet IDs (from vpc_id) to attach the cloud-operator and fargate-inventory Lambda functions to. Required (together with security_group_ids) to enable VPC networking for these functions; leave empty to keep them outside any VPC. Subnets must have a route to the internet (e.g. via NAT gateway) or to Qualys via a proxy in order to reach gateway_url."
  default     = []
}

variable "security_group_ids" {
  type        = list(string)
  description = "Optional. Security group IDs (from vpc_id) to attach to the cloud-operator and fargate-inventory Lambda functions. Required (together with subnet_ids) to enable VPC networking for these functions; leave empty to keep them outside any VPC."
  default     = []
}

variable "tags" {
  type        = map(string)
  description = "Additional tags applied to all resources that support tagging."
  default     = {}
}
