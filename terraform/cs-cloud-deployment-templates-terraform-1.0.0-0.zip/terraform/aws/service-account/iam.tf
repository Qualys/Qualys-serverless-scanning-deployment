data "aws_iam_policy_document" "events_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "lambda_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

# ========================================
# EventBridge -> SQS role
# ========================================
resource "aws_iam_role" "eventbridge_to_sqs" {
  name               = "qualys-cloud-scanning-eventbridge-to-sqs-role"
  assume_role_policy = data.aws_iam_policy_document.events_assume.json
  tags               = local.common_tags
}

resource "aws_iam_role_policy" "eventbridge_to_sqs" {
  name = "EventBridgeToSQSPolicy"
  role = aws_iam_role.eventbridge_to_sqs.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = "sqs:SendMessage"
      Resource = compact([
        aws_sqs_queue.workload_events.arn,
        local.fargate_inventory_enabled ? aws_sqs_queue.fargate_inventory[0].arn : "",
        local.any_workload_disabled ? aws_sqs_queue.events_disabled_capture[0].arn : "",
      ])
    }]
  })
}

# ========================================
# Orchestrator (Lambda-scan) execution role
# ========================================
resource "aws_iam_role" "orchestrator" {
  name               = "QualysCloudOperatorOrchestratorRole"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
  tags               = merge(local.common_tags, { Name = "QualysCloudOperatorOrchestratorRole" })
}

resource "aws_iam_role_policy" "orchestrator_logs" {
  name = "CloudWatchLogsPolicy"
  role = aws_iam_role.orchestrator.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
      Resource = "${aws_cloudwatch_log_group.cloud_operator.arn}:*"
    }]
  })
}

# Required for the Lambda service to create/attach/delete the ENI it needs when
# vpc_config is set (subnet_ids provided). Same permissions as the AWS managed
# policy AWSLambdaVPCAccessExecutionRole, granted inline instead. Only created
# when VPC config is used, since IAM policies require at least one Statement.
resource "aws_iam_role_policy" "orchestrator_vpc_access" {
  count = local.use_vpc_config ? 1 : 0

  name = "VpcAccessPolicy"
  role = aws_iam_role.orchestrator.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid    = "LambdaVpcNetworkInterfaces"
      Effect = "Allow"
      Action = [
        "ec2:CreateNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DeleteNetworkInterface",
        "ec2:AssignPrivateIpAddresses",
        "ec2:UnassignPrivateIpAddresses",
      ]
      Resource = "*"
    }]
  })
}

resource "aws_iam_role_policy" "orchestrator" {
  name = "OrchestratorPolicy"
  role = aws_iam_role.orchestrator.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = concat(
      [
        {
          Effect   = "Allow"
          Action   = "sts:AssumeRole"
          Resource = "arn:${local.partition}:iam::*:role/QualysCloudOperatorRole"
        },
        {
          Effect = "Allow"
          Action = [
            "sqs:ReceiveMessage",
            "sqs:DeleteMessage",
            "sqs:GetQueueAttributes",
            "sqs:SendMessage",
          ]
          Resource = [
            aws_sqs_queue.workload_events.arn,
            aws_sqs_queue.onboarding_events.arn,
          ]
        },
      ],
      # Onboarding trigger points enqueue Fargate initial-scan units, one per
      # (account, region), onto the bulk-scan queue instead of invoking the
      # fargate-inventory function directly.
      local.fargate_inventory_enabled ? [
        {
          Sid      = "EnqueueFargateBulkScanUnits"
          Effect   = "Allow"
          Action   = "sqs:SendMessage"
          Resource = aws_sqs_queue.fargate_bulk_scan[0].arn
        }
      ] : [],
      [
        {
          Effect = "Allow"
          Action = [
            "dynamodb:GetItem",
            "dynamodb:PutItem",
            "dynamodb:UpdateItem",
            "dynamodb:DeleteItem",
            "dynamodb:Query",
            "dynamodb:Scan",
          ]
          Resource = [
            aws_dynamodb_table.lambda_scan_jobs.arn,
            aws_dynamodb_table.onboarded_accounts.arn,
          ]
        },
        {
          Sid      = "ScanLambdaFunctions"
          Effect   = "Allow"
          Action   = ["lambda:GetFunction", "lambda:GetFunctionConfiguration", "lambda:ListFunctions"]
          Resource = "*"
        },
        # Self-invoke for the Lambda-scan initial scan only (Fargate's
        # onboarding-triggered initial scan goes through the bulk-scan queue).
        {
          Sid      = "InvokeForInitialScan"
          Effect   = "Allow"
          Action   = "lambda:InvokeFunction"
          Resource = "arn:${local.partition}:lambda:${local.region}:${local.account_id}:function:qualys-cloud-operator"
        },
        {
          Sid    = "ECRImagePull"
          Effect = "Allow"
          Action = [
            "ecr:GetAuthorizationToken",
            "ecr:BatchCheckLayerAvailability",
            "ecr:GetDownloadUrlForLayer",
            "ecr:BatchGetImage",
          ]
          Resource = "*"
        },
        # Resolve Qualys credentials from Secrets Manager (qualys_secret_arn), when set.
        {
          Sid      = "QualysCredentialsSecret"
          Effect   = "Allow"
          Action   = "secretsmanager:GetSecretValue"
          Resource = "arn:${local.partition}:secretsmanager:*:${local.account_id}:secret:*"
        },
      ]
    )
  })
}

# ========================================
# Dedicated Fargate inventory execution role (least privilege)
# ========================================
resource "aws_iam_role" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name               = "QualysFargateInventoryRole"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
  tags               = merge(local.common_tags, { Name = "QualysFargateInventoryRole" })
}

resource "aws_iam_role_policy" "fargate_inventory_logs" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name = "CloudWatchLogsPolicy"
  role = aws_iam_role.fargate_inventory[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
      Resource = "${aws_cloudwatch_log_group.fargate_inventory[0].arn}:*"
    }]
  })
}

# See aws_iam_role_policy.orchestrator_vpc_access for details.
resource "aws_iam_role_policy" "fargate_inventory_vpc_access" {
  count = local.use_vpc_config ? 1 : 0

  name = "VpcAccessPolicy"
  role = aws_iam_role.fargate_inventory[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid    = "LambdaVpcNetworkInterfaces"
      Effect = "Allow"
      Action = [
        "ec2:CreateNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DeleteNetworkInterface",
        "ec2:AssignPrivateIpAddresses",
        "ec2:UnassignPrivateIpAddresses",
      ]
      Resource = "*"
    }]
  })
}

resource "aws_iam_role_policy" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name = "FargateInventoryPolicy"
  role = aws_iam_role.fargate_inventory[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:GetQueueAttributes"]
        Resource = [
          aws_sqs_queue.fargate_inventory[0].arn,
          aws_sqs_queue.fargate_bulk_scan[0].arn,
        ]
      },
      # Fan out the daily self-maintaining rescan: this function sends its own
      # bulk-scan units back onto the queue, one per (account, region).
      {
        Sid      = "FanOutBulkScanUnits"
        Effect   = "Allow"
        Action   = "sqs:SendMessage"
        Resource = aws_sqs_queue.fargate_bulk_scan[0].arn
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:DeleteItem",
          "dynamodb:Query",
          "dynamodb:Scan",
        ]
        Resource = [
          aws_dynamodb_table.fargate_cache["dedup"].arn,
          aws_dynamodb_table.fargate_cache["service"].arn,
          aws_dynamodb_table.fargate_cache["taskdef"].arn,
          aws_dynamodb_table.onboarded_accounts.arn,
        ]
      },
      {
        Effect   = "Allow"
        Action   = "sts:AssumeRole"
        Resource = "arn:${local.partition}:iam::*:role/QualysCloudOperatorRole"
      },
      {
        Sid    = "FargateInventoryCollection"
        Effect = "Allow"
        Action = [
          "ecs:ListClusters",
          "ecs:ListTasks",
          "ecs:DescribeServices",
          "ecs:DescribeTaskDefinition",
          "ecs:DescribeTasks",
        ]
        Resource = "*"
      },
      {
        Sid    = "ECRImagePull"
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken",
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
        ]
        Resource = "*"
      },
      # Resolve Qualys credentials from Secrets Manager (qualys_secret_arn), when set.
      {
        Sid      = "QualysCredentialsSecret"
        Effect   = "Allow"
        Action   = "secretsmanager:GetSecretValue"
        Resource = "arn:${local.partition}:secretsmanager:*:${local.account_id}:secret:*"
      },
    ]
  })
}
