# Cross-region EventBridge rules for the service account.
#
# CloudFormation StackSets are used because Terraform providers cannot be
# generated from a list of regions. A single StackSet is created in the primary
# region; one StackSet instance is deployed into each secondary region.
# This removes the need for one aliased provider and one module call per region.

locals {
  secondary_region_set  = toset(var.secondary_regions)
  central_event_bus_arn = "arn:${local.partition}:events:${local.region}:${local.account_id}:event-bus/default"
}

# Administration role assumed by AWS CloudFormation to orchestrate the StackSet.
resource "aws_iam_role" "secondary_region_stackset_admin" {
  count = local.has_secondary_regions ? 1 : 0

  name = "QualysCloudScanningStackSetAdministrationRole"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "cloudformation.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "secondary_region_stackset_admin" {
  count = local.has_secondary_regions ? 1 : 0

  name = "AssumeStackSetExecutionRole"
  role = aws_iam_role.secondary_region_stackset_admin[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "sts:AssumeRole"
      Resource = aws_iam_role.secondary_region_stackset_execution[0].arn
    }]
  })
}

# Execution role assumed by the StackSet in each target region to create the
# EventBridge rules and forwarding IAM role.
resource "aws_iam_role" "secondary_region_stackset_execution" {
  count = local.has_secondary_regions ? 1 : 0

  name = "QualysCloudScanningStackSetExecutionRole"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { AWS = aws_iam_role.secondary_region_stackset_admin[0].arn }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "secondary_region_stackset_execution" {
  count = local.has_secondary_regions ? 1 : 0

  name = "StackSetExecutionPolicy"
  role = aws_iam_role.secondary_region_stackset_execution[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        # StackSets (self-managed permission model) require the execution
        # role to be able to manage the underlying per-account/region stack
        # it instantiates from the StackSet template, in addition to
        # whatever permissions the template's own resources need. Without
        # this, aws_cloudformation_stack_set_instance creation fails with
        # "not authorized to perform: cloudformation:CreateStack".
        Sid    = "CloudFormationStackManagement"
        Effect = "Allow"
        Action = [
          "cloudformation:CreateStack",
          "cloudformation:UpdateStack",
          "cloudformation:DeleteStack",
          "cloudformation:DescribeStacks",
          "cloudformation:DescribeStackEvents",
          "cloudformation:GetTemplate",
          "cloudformation:GetTemplateSummary",
          "cloudformation:ListStackResources",
        ]
        Resource = "arn:${local.partition}:cloudformation:*:${local.account_id}:stack/StackSet-*/*"
      },
      {
        Sid    = "EventBridgeManagement"
        Effect = "Allow"
        Action = [
          "events:PutRule",
          "events:DeleteRule",
          "events:DescribeRule",
          "events:EnableRule",
          "events:DisableRule",
          "events:PutTargets",
          "events:RemoveTargets",
          "events:ListTargetsByRule",
          "events:TagResource",
          "events:UntagResource",
        ]
        Resource = [
          "arn:${local.partition}:events:*:${local.account_id}:rule/qualys-lambda-function-events-to-service-account",
          "arn:${local.partition}:events:*:${local.account_id}:rule/qualys-ecs-task-state-change-*",
        ]
      },
      {
        Sid    = "IAMRoleManagement"
        Effect = "Allow"
        Action = [
          "iam:CreateRole",
          "iam:DeleteRole",
          "iam:GetRole",
          "iam:PutRolePolicy",
          "iam:DeleteRolePolicy",
          "iam:TagRole",
          "iam:UntagRole",
          "iam:ListRoleTags",
          "iam:PassRole",
        ]
        Resource = "arn:${local.partition}:iam::${local.account_id}:role/qualys-eb-fwd-*"
      },
    ]
  })
}

# StackSet that deploys Lambda and Fargate EventBridge forwarding rules into
# every secondary region from a single region list.
resource "aws_cloudformation_stack_set" "secondary_region_eventbridge" {
  count = local.has_secondary_regions ? 1 : 0

  name             = "qualys-service-account-secondary-eventbridge"
  template_body    = file("${path.module}/secondary-region-eventbridge-stackset.yaml")
  permission_model = "SELF_MANAGED"
  capabilities     = ["CAPABILITY_IAM", "CAPABILITY_NAMED_IAM"]
  tags             = local.common_tags

  administration_role_arn = aws_iam_role.secondary_region_stackset_admin[0].arn
  execution_role_name     = aws_iam_role.secondary_region_stackset_execution[0].name

  parameters = {
    CentralEventBusArn     = local.central_event_bus_arn
    EnableFargateInventory = local.fargate_inventory_service_account ? "true" : "false"
    EnableLambdaScanning   = var.enable_lambda_scanning ? "true" : "false"
  }

  # Must also depend on the inline policies (not just the roles) so that on
  # `terraform destroy` the policies aren't torn down before this StackSet
  # (and, transitively, its instances) — without the execution role's
  # cloudformation:* permissions, StackSet instance deletion fails with
  # "not authorized to perform: cloudformation:DescribeStacks" and the
  # instance is left in a stuck FAILED/INOPERABLE state.
  depends_on = [
    aws_iam_role.secondary_region_stackset_admin,
    aws_iam_role.secondary_region_stackset_execution,
    aws_iam_role_policy.secondary_region_stackset_admin,
    aws_iam_role_policy.secondary_region_stackset_execution,
  ]
}

resource "aws_cloudformation_stack_set_instance" "secondary_region_eventbridge" {
  for_each = local.secondary_region_set

  region         = each.key
  stack_set_name = aws_cloudformation_stack_set.secondary_region_eventbridge[0].name

  operation_preferences {
    max_concurrent_percentage    = 100
    failure_tolerance_percentage = 0
    concurrency_mode             = "SOFT_FAILURE_TOLERANCE"
    region_concurrency_type      = "PARALLEL"
  }

  timeouts {
    create = "30m"
    update = "30m"
    delete = "30m"
  }
}
