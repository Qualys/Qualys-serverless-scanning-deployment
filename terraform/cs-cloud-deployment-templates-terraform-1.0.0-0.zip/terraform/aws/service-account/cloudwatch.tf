resource "aws_cloudwatch_metric_alarm" "orchestrator_errors" {
  alarm_name          = "qualys-cloud-operator-errors"
  alarm_description   = "Alert when orchestrator Lambda has errors"
  namespace           = "AWS/Lambda"
  metric_name         = "Errors"
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = 5
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = aws_lambda_function.cloud_operator.function_name
  }

  tags = local.common_tags
}

resource "aws_cloudwatch_metric_alarm" "sqs_queue_depth" {
  alarm_name          = "qualys-lambda-events-queue-depth"
  alarm_description   = "Alert when SQS queue has too many messages"
  namespace           = "AWS/SQS"
  metric_name         = "ApproximateNumberOfMessagesVisible"
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 2
  threshold           = 100
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    QueueName = aws_sqs_queue.workload_events.name
  }

  tags = local.common_tags
}

resource "aws_cloudwatch_metric_alarm" "events_disabled_capture_depth" {
  count = local.any_workload_disabled ? 1 : 0

  alarm_name          = "qualys-events-disabled-capture-depth"
  alarm_description   = "Alert when events are landing in the disabled scanning capture queue"
  namespace           = "AWS/SQS"
  metric_name         = "ApproximateNumberOfMessagesVisible"
  statistic           = "Average"
  period              = 300
  evaluation_periods  = 1
  threshold           = 1
  comparison_operator = "GreaterThanThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    QueueName = aws_sqs_queue.events_disabled_capture[0].name
  }

  tags = local.common_tags
}

resource "aws_cloudwatch_metric_alarm" "dlq_messages" {
  alarm_name          = "qualys-lambda-events-dlq-messages"
  alarm_description   = "Alert when messages appear in DLQ"
  namespace           = "AWS/SQS"
  metric_name         = "ApproximateNumberOfMessagesVisible"
  statistic           = "Average"
  period              = 60
  evaluation_periods  = 1
  threshold           = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "notBreaching"

  dimensions = {
    QueueName = aws_sqs_queue.workload_events_dlq.name
  }

  tags = local.common_tags
}
