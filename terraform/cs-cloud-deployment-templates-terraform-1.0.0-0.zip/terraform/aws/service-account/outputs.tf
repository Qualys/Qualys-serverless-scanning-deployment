output "lambda_scan_jobs_table_name" {
  description = "DynamoDB table for Lambda scan jobs"
  value       = aws_dynamodb_table.lambda_scan_jobs.name
}

output "onboarded_accounts_table_name" {
  description = "DynamoDB table for onboarded accounts"
  value       = aws_dynamodb_table.onboarded_accounts.name
}

output "workload_events_queue_url" {
  description = "SQS queue URL for workload events"
  value       = aws_sqs_queue.workload_events.url
}

output "workload_events_queue_arn" {
  description = "SQS queue ARN for workload events"
  value       = aws_sqs_queue.workload_events.arn
}

output "onboarding_events_queue_url" {
  description = "SQS queue URL for account onboarding events"
  value       = aws_sqs_queue.onboarding_events.url
}

output "onboarding_events_queue_arn" {
  description = "SQS queue ARN for account onboarding events (target-account notifier target)"
  value       = aws_sqs_queue.onboarding_events.arn
}

output "cloud_operator_arn" {
  description = "Cloud-operator Lambda function ARN"
  value       = aws_lambda_function.cloud_operator.arn
}

output "eventbridge_to_sqs_role_arn" {
  description = "Role ARN EventBridge assumes to deliver events to SQS"
  value       = aws_iam_role.eventbridge_to_sqs.arn
}

output "central_event_bus_arn" {
  description = "ARN of the service-account default event bus (forwarding target for secondary regions)"
  value       = "arn:${local.partition}:events:${local.region}:${local.account_id}:event-bus/default"
}

output "service_account_id" {
  description = "Service account ID (used as external ID in cross-account roles)"
  value       = local.service_account_id
}

output "fargate_inventory_queue_url" {
  description = "SQS queue URL for Fargate inventory events (null when Fargate is disabled)"
  value       = local.fargate_inventory_enabled ? aws_sqs_queue.fargate_inventory[0].url : null
}

output "fargate_inventory_arn" {
  description = "Fargate inventory Lambda function ARN (null when Fargate is disabled)"
  value       = local.fargate_inventory_enabled ? aws_lambda_function.fargate_inventory[0].arn : null
}

output "fargate_bulk_scan_queue_url" {
  description = "SQS queue URL for Fargate bulk-scan fan-out units (null when Fargate is disabled)"
  value       = local.fargate_inventory_enabled ? aws_sqs_queue.fargate_bulk_scan[0].url : null
}
