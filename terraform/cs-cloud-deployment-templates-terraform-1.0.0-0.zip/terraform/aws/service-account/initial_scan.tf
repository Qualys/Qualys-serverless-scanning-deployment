# Equivalent of the CloudFormation Custom::InitialScan resource. The CFN custom
# resource path in the handler requires the CloudFormation event envelope
# (RequestType + ResponseURL), which a direct invoke cannot provide, so instead
# invoke the same scan entry points that handler ultimately triggers. Both scan
# the service account only — target accounts self-onboard via the onboarding
# queue and get their initial scans there.

# Register the service account in the onboarded-accounts table. CloudFormation's
# Custom::InitialScan resource does this as part of its create/update handshake
# with the orchestrator, but Terraform has no equivalent handshake mechanism to
# trigger it the same way, so the initial-scan invocations below can't do it
# either. Without this resource the service account's Lambda/Fargate workloads
# would still get scanned, but the account itself would never get a row here
# (unlike target accounts, which self-onboard via the onboarding-notifier
# queue).
resource "aws_dynamodb_table_item" "service_account_onboarded" {
  count = var.scan_service_account ? 1 : 0

  table_name = aws_dynamodb_table.onboarded_accounts.name
  hash_key   = aws_dynamodb_table.onboarded_accounts.hash_key

  item = jsonencode({
    account_id   = { S = local.service_account_id }
    status       = { S = "active" }
    onboarded_at = { S = timestamp() }
    updated_at   = { S = timestamp() }
    account_type = { S = "service" }
    regions      = { SS = split(",", local.regions_csv) }
  })

  lifecycle {
    ignore_changes = [item]
  }
}

# Initial Lambda function scan: a types.ScanRequest against the cloud-operator.
resource "aws_lambda_invocation" "initial_lambda_scan" {
  count = (var.enable_lambda_scanning && var.scan_service_account) ? 1 : 0

  function_name = aws_lambda_function.cloud_operator.function_name

  input = jsonencode({
    workload_type      = "lambda"
    target_account_ids = [local.service_account_id]
    regions            = split(",", local.regions_csv)
  })

  depends_on = [
    aws_lambda_event_source_mapping.cloud_operator,
    aws_dynamodb_table.onboarded_accounts,
  ]
}

# Initial Fargate inventory scan: a workload_type=fargate request against the
# dedicated fargate-inventory function. Explicit target_account_ids make the
# collector scan inline (bounded: one account); the daily bulk-scan schedule
# handles the self-maintaining rescan of every onboarded account.
resource "aws_lambda_invocation" "initial_fargate_scan" {
  count = local.fargate_inventory_service_account ? 1 : 0

  function_name = aws_lambda_function.fargate_inventory[0].function_name

  input = jsonencode({
    workload_type      = "fargate"
    target_account_ids = [local.service_account_id]
    regions            = split(",", local.regions_csv)
  })

  depends_on = [aws_lambda_event_source_mapping.fargate_bulk_scan]
}
