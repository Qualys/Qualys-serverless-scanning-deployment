# ========================================
# Onboarding events queue (target-account self-onboarding)
# ========================================
resource "aws_sqs_queue" "onboarding_events_dlq" {
  name                      = "qualys-onboarding-events-dlq"
  message_retention_seconds = 1209600 # 14 days
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_sqs_queue" "onboarding_events" {
  name                       = "qualys-onboarding-events"
  visibility_timeout_seconds = 1800    # 2x max Lambda timeout (900s) for safety
  message_retention_seconds  = 1209600 # 14 days
  receive_wait_time_seconds  = 20      # long polling
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.onboarding_events_dlq.arn
    maxReceiveCount     = 5
  })

  tags = local.common_tags
}

# Allow the target-account onboarding notifier role to send, from the explicit
# account list and/or from any account in the AWS Organization.
resource "aws_sqs_queue_policy" "onboarding_events" {
  count = (local.has_target_accounts || local.has_organization_id) ? 1 : 0

  queue_url = aws_sqs_queue.onboarding_events.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = concat(
      local.has_target_accounts ? [
        {
          Sid       = "AllowOnboardingNotifierFromTargetAccounts"
          Effect    = "Allow"
          Principal = { AWS = "*" }
          Action    = "sqs:SendMessage"
          Resource  = aws_sqs_queue.onboarding_events.arn
          Condition = {
            StringLike   = { "aws:PrincipalArn" = "arn:${local.partition}:iam::*:role/qualys-cloud-scanning-notifier-role" }
            StringEquals = { "aws:PrincipalAccount" = var.target_account_ids }
          }
        }
      ] : [],
      local.has_organization_id ? [
        {
          Sid       = "AllowOnboardingNotifierFromOrganization"
          Effect    = "Allow"
          Principal = { AWS = "*" }
          Action    = "sqs:SendMessage"
          Resource  = aws_sqs_queue.onboarding_events.arn
          Condition = {
            StringLike   = { "aws:PrincipalArn" = "arn:${local.partition}:iam::*:role/qualys-cloud-scanning-notifier-role" }
            StringEquals = { "aws:PrincipalOrgID" = local.organization_ids }
          }
        }
      ] : []
    )
  })
}

# ========================================
# Lambda workload events queue
# ========================================
resource "aws_sqs_queue" "workload_events_dlq" {
  name                      = "qualys-lambda-events-dlq"
  message_retention_seconds = 1209600 # 14 days
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_sqs_queue" "workload_events" {
  name                       = "qualys-lambda-events"
  visibility_timeout_seconds = 900     # 3x Lambda timeout
  message_retention_seconds  = 1209600 # 14 days
  receive_wait_time_seconds  = 20      # long polling
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.workload_events_dlq.arn
    maxReceiveCount     = 10
  })

  tags = local.common_tags
}

resource "aws_sqs_queue_policy" "workload_events" {
  queue_url = aws_sqs_queue.workload_events.id

  # Target accounts never write to this queue directly: they PutEvents to this
  # account's default event bus and the rules in eventbridge.tf do the SQS send,
  # so no cross-account sqs:SendMessage grant is required.
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowEventBridgeFromServiceAccount"
        Effect    = "Allow"
        Principal = { Service = "events.amazonaws.com" }
        Action    = "sqs:SendMessage"
        Resource  = aws_sqs_queue.workload_events.arn
        Condition = {
          StringEquals = { "aws:SourceAccount" = local.account_id }
          ArnLike      = { "aws:SourceArn" = "arn:${local.partition}:events:*:${local.account_id}:rule/qualys-lambda-function-events*" }
        }
      }
    ]
  })
}

# ========================================
# Fargate inventory queue (dedicated; 1 image, 2 functions topology)
# ========================================
resource "aws_sqs_queue" "fargate_inventory_dlq" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                      = "qualys-fargate-inventory-events-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_sqs_queue" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                       = "qualys-fargate-inventory-events"
  visibility_timeout_seconds = 1800 # 2x max Lambda timeout (900s); must exceed function timeout
  message_retention_seconds  = 1209600
  receive_wait_time_seconds  = 20
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.fargate_inventory_dlq[0].arn
    maxReceiveCount     = 10
  })

  tags = local.common_tags
}

resource "aws_sqs_queue_policy" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  queue_url = aws_sqs_queue.fargate_inventory[0].id

  # Target accounts and secondary regions never write to this queue directly:
  # they PutEvents to this account's default event bus and the
  # qualys-ecs-task-state-change rule does the SQS send, so no cross-account
  # sqs:SendMessage grant is required.
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowEventBridgeFromServiceAccount"
        Effect    = "Allow"
        Principal = { Service = "events.amazonaws.com" }
        Action    = "sqs:SendMessage"
        Resource  = aws_sqs_queue.fargate_inventory[0].arn
        Condition = {
          StringEquals = { "aws:SourceAccount" = local.account_id }
          ArnLike      = { "aws:SourceArn" = "arn:${local.partition}:events:*:${local.account_id}:rule/qualys-ecs-task-state-change*" }
        }
      }
    ]
  })
}

# ========================================
# Fargate bulk-scan fan-out queue (BatchSize=1 scan units)
# ========================================
# One message = one bounded (account, region) scan unit. Producers: the
# fargate-inventory function (daily self-maintaining rescan fan-out) and the
# cloud-operator (onboarding-triggered initial scans). Consumer: the
# fargate-inventory function only.
resource "aws_sqs_queue" "fargate_bulk_scan_dlq" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                      = "qualys-fargate-bulk-scan-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_sqs_queue" "fargate_bulk_scan" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                       = "qualys-fargate-bulk-scan"
  visibility_timeout_seconds = 1800 # 2x max Lambda timeout (900s); must exceed function timeout
  message_retention_seconds  = 1209600
  receive_wait_time_seconds  = 20
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.fargate_bulk_scan_dlq[0].arn
    maxReceiveCount     = 5
  })

  tags = local.common_tags
}
