resource "aws_dynamodb_table" "lambda_scan_jobs" {
  name         = "qualys-lambda-scan-jobs"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "function_arn"

  attribute {
    name = "function_arn"
    type = "S"
  }

  ttl {
    enabled        = true
    attribute_name = "ttl"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  tags = merge(local.common_tags, { Name = "lambda-scan-jobs" })
}

# Keyed by account_id only; regions live in a StringSet attribute (see
# store.AddOnboardedAccountRegion in cloud-operator).
resource "aws_dynamodb_table" "onboarded_accounts" {
  name         = "qualys-onboarded-accounts"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "account_id"

  attribute {
    name = "account_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  tags = merge(local.common_tags, { Name = "onboarded-accounts" })
}

# Fargate inventory dedup + enrichment caches. Each table has a self-describing
# hash key; value attributes are defined by the cloud-operator code at runtime.
# Created only when Fargate inventory is enabled.
resource "aws_dynamodb_table" "fargate_cache" {
  for_each = local.fargate_tables

  name         = each.value.name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = each.value.hash_key

  attribute {
    name = each.value.hash_key
    type = "S"
  }

  ttl {
    enabled        = true
    attribute_name = "ttl"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true
  }

  tags = merge(local.common_tags, { Name = each.value.name })
}
