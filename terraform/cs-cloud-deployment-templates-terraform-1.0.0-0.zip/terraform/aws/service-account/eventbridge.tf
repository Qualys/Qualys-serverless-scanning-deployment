# ========================================
# Lambda function events -> lambda workload SQS
# ========================================
resource "aws_cloudwatch_event_rule" "workload_function_events" {
  name        = "qualys-lambda-function-events"
  description = "Capture Lambda CreateFunction, UpdateFunctionCode, and DeleteFunction events originating in this account and region"
  state       = (var.scan_service_account && var.enable_lambda_scanning) ? "ENABLED" : "DISABLED"

  # account/region are pinned to this account and region so that events
  # forwarded onto this bus from secondary regions or target accounts are
  # handled ONLY by cross_region_forwarding / target_account_forwarding and are
  # not enqueued twice.
  event_pattern = jsonencode({
    account       = [local.account_id]
    region        = [local.region]
    source        = ["aws.lambda"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["lambda.amazonaws.com"]
      eventName   = ["CreateFunction20150331", "UpdateFunctionCode20150331v2", "DeleteFunction20150331"]
      errorCode   = [{ exists = false }]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "workload_function_events" {
  rule      = aws_cloudwatch_event_rule.workload_function_events.name
  target_id = "WorkloadEventsQueue"
  arn       = aws_sqs_queue.workload_events.arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn
}

# ========================================
# Cross-region: bus policies + forwarding rule (primary region)
# ========================================
# Use a single aws_cloudwatch_event_bus_policy instead of multiple
# aws_cloudwatch_event_permission resources. The permission resource has a
# provider-level read bug: it unmarshals the entire default event bus policy
# and fails whenever any statement has an array-form Action field, which AWS
# can return even for statements originally created with a single action string.
# The bus policy resource manages the whole policy document as text, avoiding
# that unmarshal path.
data "aws_iam_policy_document" "default_event_bus_policy" {
  count = local.has_secondary_regions || local.has_target_accounts || local.has_organization_id ? 1 : 0

  # Allow same-account secondary regions to PutEvents onto the default bus.
  dynamic "statement" {
    for_each = local.has_secondary_regions ? [local.account_id] : []
    content {
      sid       = "AllowCrossRegionFromSameAccount"
      effect    = "Allow"
      actions   = ["events:PutEvents"]
      resources = ["arn:${local.partition}:events:${local.region}:${local.account_id}:event-bus/default"]
      principals {
        type        = "AWS"
        identifiers = [statement.value]
      }
    }
  }

  # Allow each target account to PutEvents onto the default bus.
  dynamic "statement" {
    for_each = local.has_target_accounts ? var.target_account_ids : []
    content {
      sid       = "AllowTargetAccount${statement.value}PutEvents"
      effect    = "Allow"
      actions   = ["events:PutEvents"]
      resources = ["arn:${local.partition}:events:${local.region}:${local.account_id}:event-bus/default"]
      principals {
        type        = "AWS"
        identifiers = [statement.value]
      }
    }
  }

  # Allow any account in the AWS Organizations to PutEvents onto the default bus.
  dynamic "statement" {
    for_each = local.has_organization_id ? [local.organization_ids] : []
    content {
      sid       = "AllowOrganizationPutEvents"
      effect    = "Allow"
      actions   = ["events:PutEvents"]
      resources = ["arn:${local.partition}:events:${local.region}:${local.account_id}:event-bus/default"]
      principals {
        type        = "AWS"
        identifiers = ["*"]
      }
      condition {
        test     = "StringEquals"
        variable = "aws:PrincipalOrgID"
        values   = statement.value
      }
    }
  }
}

resource "aws_cloudwatch_event_bus_policy" "default" {
  count = local.has_secondary_regions || local.has_target_accounts || local.has_organization_id ? 1 : 0

  event_bus_name = "default"
  policy         = data.aws_iam_policy_document.default_event_bus_policy[0].json
}

# Receive Lambda events forwarded from secondary regions via the default bus and
# route them to the workload SQS. Authorized by the queue policy SourceArn pin.
resource "aws_cloudwatch_event_rule" "cross_region_forwarding" {
  count = local.has_secondary_regions ? 1 : 0

  name        = "qualys-lambda-function-events-cross-region"
  description = "Receive Lambda events forwarded from same-account secondary regions via event bus and route to SQS"
  state       = var.enable_lambda_scanning ? "ENABLED" : "DISABLED"

  event_pattern = jsonencode({
    account       = [local.account_id]
    source        = ["aws.lambda"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["lambda.amazonaws.com"]
      eventName   = ["CreateFunction20150331", "UpdateFunctionCode20150331v2", "DeleteFunction20150331"]
      errorCode   = [{ exists = false }]
      awsRegion   = var.secondary_regions
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "cross_region_forwarding" {
  count = local.has_secondary_regions ? 1 : 0

  rule      = aws_cloudwatch_event_rule.cross_region_forwarding[0].name
  target_id = "WorkloadEventsQueueCrossRegion"
  arn       = aws_sqs_queue.workload_events.arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn
}

# Receive Lambda events forwarded from TARGET accounts via the default bus and
# route them to the workload SQS. Target accounts PutEvents onto this bus (they
# never write to the queue directly), so without this rule cross-account Lambda
# events are dropped.
resource "aws_cloudwatch_event_rule" "target_account_forwarding" {
  count = (local.has_target_accounts || local.has_organization_id) ? 1 : 0

  name        = "qualys-lambda-function-events-target-account"
  description = "Receive Lambda events forwarded from target accounts via event bus and route to SQS"
  state       = var.enable_lambda_scanning ? "ENABLED" : "DISABLED"

  event_pattern = jsonencode({
    account       = [{ "anything-but" = local.account_id }]
    source        = ["aws.lambda"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["lambda.amazonaws.com"]
      eventName   = ["CreateFunction20150331", "UpdateFunctionCode20150331v2", "DeleteFunction20150331"]
      errorCode   = [{ exists = false }]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "target_account_forwarding" {
  count = (local.has_target_accounts || local.has_organization_id) ? 1 : 0

  rule      = aws_cloudwatch_event_rule.target_account_forwarding[0].name
  target_id = "WorkloadEventsQueueTargetAccount"
  arn       = aws_sqs_queue.workload_events.arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn
}

# ========================================
# ECS Fargate inventory rules
# ========================================
# Native "ECS Task State Change" RUNNING events -> dedicated Fargate SQS.
resource "aws_cloudwatch_event_rule" "ecs_task_state_change" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name        = "qualys-ecs-task-state-change"
  description = "Capture ECS Task State Change events for Fargate inventory collection"
  # ENABLED whenever Fargate is enabled (not gated on scan_service_account):
  # this rule also routes cross-account events forwarded onto the default bus,
  # so target-only deployments still need it. Own-account events are filtered
  # by the collector via SCAN_SERVICE_ACCOUNT.
  state = "ENABLED"

  # Only RUNNING events carry resolved container imageDigests, so filter at
  # the source: digest-less PROVISIONING/PENDING/STOPPED events never reach
  # the Lambda. (imageDigest is nested in containers[] and cannot be matched
  # directly; lastStatus=RUNNING is the reliable proxy.)
  # desiredStatus=RUNNING excludes teardown events where lastStatus is
  # briefly RUNNING while desiredStatus transitions to STOPPED (stop-task).
  event_pattern = jsonencode({
    source        = ["aws.ecs"]
    "detail-type" = ["ECS Task State Change"]
    detail = {
      "$or" = [
        { launchType = ["FARGATE"] },
        { capacityProviderName = ["FARGATE", "FARGATE_SPOT"] },
      ]
      lastStatus    = ["RUNNING"]
      desiredStatus = ["RUNNING"]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "ecs_task_state_change" {
  count = local.fargate_inventory_enabled ? 1 : 0

  rule      = aws_cloudwatch_event_rule.ecs_task_state_change[0].name
  target_id = "ECSTaskStateChangeQueue"
  arn       = aws_sqs_queue.fargate_inventory[0].arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn

  # Failed deliveries land here instead of vanishing (this rule also re-matches
  # events forwarded bus-to-bus from other regions/accounts).
  dead_letter_config {
    arn = aws_sqs_queue.fargate_events_rule_dlq[0].arn
  }
}

# DLQ for ecs_task_state_change delivery failures (CFN: FargateEventsRuleDLQ).
resource "aws_sqs_queue" "fargate_events_rule_dlq" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                      = "qualys-fargate-events-rule-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_sqs_queue_policy" "fargate_events_rule_dlq" {
  count = local.fargate_inventory_enabled ? 1 : 0

  queue_url = aws_sqs_queue.fargate_events_rule_dlq[0].id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "AllowEventBridgeDeadLetter"
      Effect    = "Allow"
      Principal = { Service = "events.amazonaws.com" }
      Action    = "sqs:SendMessage"
      Resource  = aws_sqs_queue.fargate_events_rule_dlq[0].arn
      Condition = {
        ArnEquals = { "aws:SourceArn" = aws_cloudwatch_event_rule.ecs_task_state_change[0].arn }
      }
    }]
  })
}

# ========================================
# Disabled-state capture (observability)
# ========================================
# When a workload is disabled its routing rules are DISABLED and matching events
# are silently dropped from the default bus. These rules capture them instead so
# the drop is visible in an alarm. Nothing consumes the queues, so retention is
# deliberately short (disabled_event_capture_retention_seconds): the backlog and
# the alarm clear themselves once capture is no longer needed.
resource "aws_sqs_queue" "events_disabled_capture" {
  count = local.any_workload_disabled ? 1 : 0

  name                      = "qualys-events-disabled-capture"
  message_retention_seconds = var.disabled_event_capture_retention_seconds
  sqs_managed_sse_enabled   = true

  tags = local.common_tags
}

resource "aws_cloudwatch_event_rule" "lambda_disabled_capture" {
  count = local.lambda_scanning_disabled ? 1 : 0

  name        = "qualys-lambda-function-events-disabled-dlq"
  description = "Catch Lambda events when Lambda scanning is disabled"
  state       = "ENABLED"

  event_pattern = jsonencode({
    source        = ["aws.lambda"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["lambda.amazonaws.com"]
      eventName   = ["CreateFunction20150331", "UpdateFunctionCode20150331v2", "DeleteFunction20150331"]
      errorCode   = [{ exists = false }]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "lambda_disabled_capture" {
  count = local.lambda_scanning_disabled ? 1 : 0

  rule      = aws_cloudwatch_event_rule.lambda_disabled_capture[0].name
  target_id = "DisabledEventsCaptureTarget"
  arn       = aws_sqs_queue.events_disabled_capture[0].arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn
}

resource "aws_cloudwatch_event_rule" "fargate_disabled_capture" {
  count = local.fargate_inventory_disabled ? 1 : 0

  name        = "qualys-fargate-events-disabled-dlq"
  description = "Catch Fargate RUNNING task events when Fargate inventory is disabled"
  state       = "ENABLED"

  event_pattern = jsonencode({
    source        = ["aws.ecs"]
    "detail-type" = ["ECS Task State Change"]
    detail = {
      "$or" = [
        { launchType = ["FARGATE"] },
        { capacityProviderName = ["FARGATE", "FARGATE_SPOT"] },
      ]
      lastStatus    = ["RUNNING"]
      desiredStatus = ["RUNNING"]
    }
  })

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "fargate_disabled_capture" {
  count = local.fargate_inventory_disabled ? 1 : 0

  rule      = aws_cloudwatch_event_rule.fargate_disabled_capture[0].name
  target_id = "DisabledEventsCaptureTarget"
  arn       = aws_sqs_queue.events_disabled_capture[0].arn
  role_arn  = aws_iam_role.eventbridge_to_sqs.arn
}

# Hourly FLUSH: re-invoke the Fargate Lambda to emit count-only events for
# expired dedup entries. The handler recognises {"trigger":"flush"}.
resource "aws_cloudwatch_event_rule" "fargate_inventory_flush" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                = "qualys-fargate-inventory-flush"
  description         = "Hourly flush of accumulated Fargate inventory dedup counts"
  state               = "ENABLED" # dedup entries accumulate for target accounts too
  schedule_expression = "rate(1 hour)"

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "fargate_inventory_flush" {
  count = local.fargate_inventory_enabled ? 1 : 0

  rule      = aws_cloudwatch_event_rule.fargate_inventory_flush[0].name
  target_id = "FargateInventoryFlushTarget"
  arn       = aws_lambda_function.fargate_inventory[0].arn
  input     = jsonencode({ trigger = "flush" })
}

resource "aws_lambda_permission" "fargate_inventory_flush" {
  count = local.fargate_inventory_enabled ? 1 : 0

  statement_id  = "AllowFlushRuleInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.fargate_inventory[0].function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.fargate_inventory_flush[0].arn
}

# Daily BULK_SCAN discovery across onboarded accounts.
resource "aws_cloudwatch_event_rule" "fargate_inventory_bulk_scan" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name                = "qualys-fargate-inventory-bulk-scan"
  description         = "Daily BULK_SCAN discovery of running Fargate tasks across onboarded accounts"
  state               = "ENABLED" # rescans every onboarded account, not just the service account
  schedule_expression = "rate(24 hours)"

  tags = local.common_tags
}

resource "aws_cloudwatch_event_target" "fargate_inventory_bulk_scan" {
  count = local.fargate_inventory_enabled ? 1 : 0

  rule      = aws_cloudwatch_event_rule.fargate_inventory_bulk_scan[0].name
  target_id = "FargateInventoryBulkScanTarget"
  arn       = aws_lambda_function.fargate_inventory[0].arn
  input     = jsonencode({ workload_type = "fargate" })
}

resource "aws_lambda_permission" "fargate_inventory_bulk_scan" {
  count = local.fargate_inventory_enabled ? 1 : 0

  statement_id  = "AllowBulkScanRuleInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.fargate_inventory[0].function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.fargate_inventory_bulk_scan[0].arn
}
