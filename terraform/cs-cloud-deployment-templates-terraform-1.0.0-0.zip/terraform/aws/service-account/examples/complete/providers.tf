terraform {
  required_version = ">= 1.3"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

# Primary (deploy) region. Secondary regions are handled by the
# aws_cloudformation_stack_set_instance resources inside the root module, so no
# aliased providers are required.
provider "aws" {
  region  = var.primary_region
  profile = var.aws_profile != "" ? var.aws_profile : null
}
