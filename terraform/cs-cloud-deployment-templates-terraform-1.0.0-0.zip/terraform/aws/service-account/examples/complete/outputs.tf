output "workload_events_queue_arn" {
  description = "SQS queue ARN target accounts forward events to"
  value       = module.service_account.workload_events_queue_arn
}

output "central_event_bus_arn" {
  description = "Central event bus ARN for secondary-region forwarding"
  value       = module.service_account.central_event_bus_arn
}

output "cloud_operator_arn" {
  value = module.service_account.cloud_operator_arn
}

output "service_account_id" {
  value = module.service_account.service_account_id
}
