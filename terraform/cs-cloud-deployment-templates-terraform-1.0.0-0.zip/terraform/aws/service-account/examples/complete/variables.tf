variable "primary_region" {
  type        = string
  description = "Primary deploy region for the service account."
  default     = "us-east-1"
}

variable "aws_profile" {
  type        = string
  description = "AWS CLI profile to use for the service account (applies to every provider block, including secondary regions). Leave empty to use the ambient default credential chain (default profile, AWS_PROFILE env var, instance role, etc.)."
  default     = ""
}

variable "cloud_operator_image_uri" {
  type        = string
  description = "ECR image URI for the cloud-operator Lambda."
}

variable "gateway_url" {
  type        = string
  description = "Qualys gateway URL."
}

variable "qualys_access_token" {
  type        = string
  description = "Qualys access token."
  default     = ""
  sensitive   = true
}

variable "secondary_regions" {
  type        = list(string)
  description = "Secondary regions to capture cross-region events from. The root module deploys a CloudFormation StackSet instance into each region."
  default     = ["us-west-2"]
}

variable "target_account_ids" {
  type        = list(string)
  description = "Target AWS account IDs to scan."
  default     = []
}

variable "enable_fargate_inventory" {
  type        = bool
  description = "Enable the Fargate inventory workload."
  default     = true
}

variable "enable_lambda_scanning" {
  type        = bool
  description = "Enable Lambda function scanning. Set false to run Fargate-only."
  default     = true
}

variable "scan_service_account" {
  type        = bool
  description = "Scan Lambda functions and Fargate tasks in the service account itself. Set false to only scan target accounts."
  default     = true
}

variable "lambda_scan_max_concurrency" {
  type        = number
  description = "Maximum concurrency for the Lambda scanning event source mapping."
  default     = 50
}

variable "service_account_id" {
  type        = string
  description = "AWS account ID where this stack is deployed. Leave empty to auto-detect via the caller identity."
  default     = ""
}

variable "qualys_client_id" {
  type        = string
  description = "Optional OAuth client ID for qscanner."
  default     = ""
}

variable "qualys_client_secret" {
  type        = string
  description = "Optional OAuth client secret for qscanner."
  default     = ""
  sensitive   = true
}

variable "qualys_secret_arn" {
  type        = string
  description = "Optional Secrets Manager ARN with Qualys credentials JSON {access_token, client_id, client_secret}. When set it overrides the plaintext qualys_* inputs."
  default     = ""
}

variable "scan_types" {
  type        = string
  description = "Comma-separated scan types passed to qscanner."
  default     = "pkg,fileinsight,aiinsight"
}

variable "proxy" {
  type        = string
  description = "Optional HTTP/HTTPS proxy URL."
  default     = ""
}

variable "ca_certificate" {
  type        = string
  description = "Optional base64-encoded CA certificate."
  default     = ""
  sensitive   = true
}

variable "skip_tls_verify" {
  type        = string
  description = "Skip TLS verification for Qualys API calls (true or false)."
  default     = "false"
}

variable "log_level" {
  type        = string
  description = "Log level for the Lambda functions."
  default     = "info"
}

variable "customer_id" {
  type        = string
  description = "Qualys customer/subscription id used in v2.1 inventory events. Required for Fargate inventory."
  default     = ""
}

variable "cloud_operator_memory_size" {
  type        = number
  description = "Memory size for the orchestrator Lambda (MB)."
  default     = 2048
}

variable "cloud_operator_timeout" {
  type        = number
  description = "Timeout for the orchestrator Lambda (seconds)."
  default     = 900
}

variable "lambda_sqs_batch_size" {
  type        = number
  description = "Number of SQS messages to process in batch for the Lambda workload queue."
  default     = 1
}

variable "sqs_batch_size" {
  type        = number
  description = "Number of SQS messages to process in batch for the Fargate inventory queue."
  default     = 10
}

variable "cloud_operator_lambda_architecture" {
  type        = string
  description = "Architecture for the Lambda functions (x86_64 or arm64)."
  default     = "x86_64"
}

variable "cloud_operator_ephemeral_storage_size" {
  type        = number
  description = "Ephemeral storage (/tmp) size for the orchestrator Lambda (MB)."
  default     = 5120
}

variable "organization_id" {
  type        = string
  description = "Optional comma-separated list of AWS Organizations IDs (e.g. o-xxxxxxxxxx,o-yyyyyyyyyy)."
  default     = ""
}

variable "enable_cloud_metadata_collection" {
  type        = bool
  description = "Enrich Fargate inventory events with task-definition metadata and resource tags."
  default     = false
}

variable "lambda_log_retention_days" {
  type        = number
  description = "CloudWatch log retention for the Lambda log groups (days)."
  default     = 7
}

variable "vpc_id" {
  type        = string
  description = "Optional. VPC ID to run the cloud-operator and fargate-inventory Lambda functions in."
  default     = ""
}

variable "subnet_ids" {
  type        = list(string)
  description = "Optional. Subnet IDs (from vpc_id) to attach the cloud-operator and fargate-inventory Lambda functions to."
  default     = []
}

variable "security_group_ids" {
  type        = list(string)
  description = "Optional. Security group IDs (from vpc_id) to attach to the cloud-operator and fargate-inventory Lambda functions."
  default     = []
}
