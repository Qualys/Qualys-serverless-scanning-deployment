# Complete service-account deployment: primary-region infrastructure plus
# any secondary regions deployed via CloudFormation StackSet instances.

module "service_account" {
  source = "../.."

  service_account_id       = var.service_account_id
  cloud_operator_image_uri = var.cloud_operator_image_uri
  gateway_url              = var.gateway_url
  qualys_access_token      = var.qualys_access_token
  qualys_client_id         = var.qualys_client_id
  qualys_client_secret     = var.qualys_client_secret
  qualys_secret_arn        = var.qualys_secret_arn

  target_account_ids       = var.target_account_ids
  secondary_regions        = var.secondary_regions
  organization_id          = var.organization_id
  enable_fargate_inventory = var.enable_fargate_inventory
  enable_lambda_scanning   = var.enable_lambda_scanning
  scan_service_account     = var.scan_service_account

  scan_types                       = var.scan_types
  proxy                            = var.proxy
  ca_certificate                   = var.ca_certificate
  skip_tls_verify                  = var.skip_tls_verify
  log_level                        = var.log_level
  customer_id                      = var.customer_id
  enable_cloud_metadata_collection = var.enable_cloud_metadata_collection

  cloud_operator_memory_size            = var.cloud_operator_memory_size
  cloud_operator_timeout                = var.cloud_operator_timeout
  cloud_operator_lambda_architecture    = var.cloud_operator_lambda_architecture
  cloud_operator_ephemeral_storage_size = var.cloud_operator_ephemeral_storage_size
  lambda_scan_max_concurrency           = var.lambda_scan_max_concurrency
  lambda_sqs_batch_size                 = var.lambda_sqs_batch_size
  sqs_batch_size                        = var.sqs_batch_size
  lambda_log_retention_days             = var.lambda_log_retention_days

  vpc_id             = var.vpc_id
  subnet_ids         = var.subnet_ids
  security_group_ids = var.security_group_ids

  tags = {
    Project = "qualys-cloud-operator"
  }
}

# Secondary regions are handled inside the root module via
# aws_cloudformation_stack_set / aws_cloudformation_stack_set_instance.
# No extra module calls or provider aliases are needed.
