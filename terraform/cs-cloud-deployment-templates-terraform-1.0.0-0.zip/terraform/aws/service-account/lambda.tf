resource "aws_cloudwatch_log_group" "cloud_operator" {
  name              = "/aws/lambda/qualys-cloud-operator"
  retention_in_days = var.lambda_log_retention_days
  tags              = local.common_tags
}

# ========================================
# Cloud-operator (Lambda scanning) function
# ========================================
resource "aws_lambda_function" "cloud_operator" {
  function_name = "qualys-cloud-operator"
  package_type  = "Image"
  image_uri     = var.cloud_operator_image_uri
  role          = aws_iam_role.orchestrator.arn
  architectures = [var.cloud_operator_lambda_architecture]
  timeout       = var.cloud_operator_timeout
  memory_size   = var.cloud_operator_memory_size

  ephemeral_storage {
    size = var.cloud_operator_ephemeral_storage_size
  }

  dynamic "vpc_config" {
    for_each = local.use_vpc_config ? [1] : []
    content {
      subnet_ids         = var.subnet_ids
      security_group_ids = var.security_group_ids
    }
  }

  environment {
    variables = {
      LAMBDA_SCAN_JOBS_TABLE   = aws_dynamodb_table.lambda_scan_jobs.name
      ONBOARDED_ACCOUNTS_TABLE = aws_dynamodb_table.onboarded_accounts.name
      LAMBDA_SQS_QUEUE_URL     = aws_sqs_queue.workload_events.url
      ROLE_NAME                = "QualysCloudOperatorRole"
      SERVICE_ACCOUNT_ID       = local.service_account_id
      TARGET_ACCOUNT_IDS       = join(",", var.target_account_ids)
      REGIONS                  = local.regions_csv
      SCAN_SERVICE_ACCOUNT     = tostring(var.scan_service_account)
      QUALYS_ACCESS_TOKEN      = var.qualys_access_token
      QUALYS_CLIENT_ID         = var.qualys_client_id
      QUALYS_CLIENT_SECRET     = var.qualys_client_secret
      # When set, overrides the plaintext QUALYS_* vars above.
      QUALYS_SECRET_ARN      = var.qualys_secret_arn
      SCAN_TYPES             = var.scan_types
      GATEWAY_URL            = var.gateway_url
      PROXY                  = var.proxy
      CA_CERTIFICATE         = var.ca_certificate
      SKIP_TLS_VERIFY        = var.skip_tls_verify
      LOG_LEVEL              = var.log_level
      ENABLE_LAMBDA_SCANNING = tostring(var.enable_lambda_scanning)
      # Lambda-scan function keeps Fargate OFF; the dedicated function below owns it.
      ENABLE_FARGATE_INVENTORY = "false"
      # Onboarding trigger points enqueue Fargate initial-scan units onto this
      # queue for the dedicated fargate-inventory function; empty when Fargate
      # is disabled (which also disables the enqueue calls).
      FARGATE_BULK_SCAN_QUEUE_URL = local.fargate_inventory_enabled ? aws_sqs_queue.fargate_bulk_scan[0].url : ""
    }
  }

  depends_on = [aws_cloudwatch_log_group.cloud_operator]

  tags = merge(local.common_tags, { Name = "qualys-cloud-operator" })
}

resource "aws_lambda_event_source_mapping" "cloud_operator" {
  function_name                      = aws_lambda_function.cloud_operator.arn
  event_source_arn                   = aws_sqs_queue.workload_events.arn
  batch_size                         = var.lambda_sqs_batch_size
  maximum_batching_window_in_seconds = 5
  function_response_types            = ["ReportBatchItemFailures"]

  scaling_config {
    maximum_concurrency = var.lambda_scan_max_concurrency
  }
}

resource "aws_lambda_event_source_mapping" "cloud_operator_onboarding" {
  function_name                      = aws_lambda_function.cloud_operator.arn
  event_source_arn                   = aws_sqs_queue.onboarding_events.arn
  batch_size                         = 1
  maximum_batching_window_in_seconds = 0
  function_response_types            = ["ReportBatchItemFailures"]
}

# ========================================
# Dedicated Fargate inventory function (same image, 2nd function)
# ========================================
resource "aws_cloudwatch_log_group" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  name              = "/aws/lambda/qualys-fargate-inventory"
  retention_in_days = var.lambda_log_retention_days
  tags              = local.common_tags
}

resource "aws_lambda_function" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  function_name = "qualys-fargate-inventory"
  package_type  = "Image"
  image_uri     = var.cloud_operator_image_uri # SAME image as cloud_operator
  role          = aws_iam_role.fargate_inventory[0].arn
  architectures = [var.cloud_operator_lambda_architecture]
  timeout       = var.cloud_operator_timeout
  memory_size   = var.cloud_operator_memory_size

  ephemeral_storage {
    size = var.cloud_operator_ephemeral_storage_size
  }

  dynamic "vpc_config" {
    for_each = local.use_vpc_config ? [1] : []
    content {
      subnet_ids         = var.subnet_ids
      security_group_ids = var.security_group_ids
    }
  }

  environment {
    variables = {
      # Per-workload flags: Fargate ON, Lambda-scan OFF.
      ENABLE_FARGATE_INVENTORY = "true"
      ENABLE_LAMBDA_SCANNING   = "false"
      # Skip the service account's own Fargate tasks when target-only: the routing
      # rule still captures them; the collector filters them out on this flag.
      SCAN_SERVICE_ACCOUNT             = tostring(var.scan_service_account)
      ENABLE_CLOUD_METADATA_COLLECTION = tostring(var.enable_cloud_metadata_collection)
      INVENTORY_DEDUP_TABLE            = aws_dynamodb_table.fargate_cache["dedup"].name
      SERVICE_CACHE_TABLE              = aws_dynamodb_table.fargate_cache["service"].name
      INVENTORY_TASKDEF_CACHE_TABLE    = aws_dynamodb_table.fargate_cache["taskdef"].name
      ONBOARDED_ACCOUNTS_TABLE         = aws_dynamodb_table.onboarded_accounts.name
      FARGATE_INVENTORY_QUEUE_URL      = aws_sqs_queue.fargate_inventory[0].url
      # Bulk-scan fan-out (BatchSize=1): the daily rescan and onboarding-triggered
      # initial scans send one (account, region) unit per message onto this queue.
      FARGATE_BULK_SCAN_QUEUE_URL = aws_sqs_queue.fargate_bulk_scan[0].url
      GATEWAY_URL                 = var.gateway_url
      INVENTORY_API_PATH          = "/cs/v1.1/cloud/inventory/bulk/uploadEvents"
      CUSTOMER_ID                 = var.customer_id
      QUALYS_ACCESS_TOKEN         = var.qualys_access_token
      QUALYS_CLIENT_ID            = var.qualys_client_id
      QUALYS_CLIENT_SECRET        = var.qualys_client_secret
      # When set, overrides the plaintext QUALYS_* vars above.
      QUALYS_SECRET_ARN  = var.qualys_secret_arn
      PROXY              = var.proxy
      CA_CERTIFICATE     = var.ca_certificate
      SKIP_TLS_VERIFY    = var.skip_tls_verify
      LOG_LEVEL          = var.log_level
      ROLE_NAME          = "QualysCloudOperatorRole"
      SERVICE_ACCOUNT_ID = local.service_account_id
      TARGET_ACCOUNT_IDS = join(",", var.target_account_ids)
      REGIONS            = local.regions_csv
    }
  }

  depends_on = [aws_cloudwatch_log_group.fargate_inventory]

  tags = merge(local.common_tags, { Name = "qualys-fargate-inventory" })
}

resource "aws_lambda_event_source_mapping" "fargate_inventory" {
  count = local.fargate_inventory_enabled ? 1 : 0

  function_name                      = aws_lambda_function.fargate_inventory[0].arn
  event_source_arn                   = aws_sqs_queue.fargate_inventory[0].arn
  batch_size                         = var.sqs_batch_size
  maximum_batching_window_in_seconds = 5
  function_response_types            = ["ReportBatchItemFailures"]

  scaling_config {
    maximum_concurrency = 10
  }
}

# BatchSize=1: each message is a bounded, independently-retryable (account,
# region) scan unit — never batched with realtime ECS events or other units.
resource "aws_lambda_event_source_mapping" "fargate_bulk_scan" {
  count = local.fargate_inventory_enabled ? 1 : 0

  function_name           = aws_lambda_function.fargate_inventory[0].arn
  event_source_arn        = aws_sqs_queue.fargate_bulk_scan[0].arn
  batch_size              = 1
  function_response_types = ["ReportBatchItemFailures"]
}
